% createInitStruct

initializeStruct.TalkToHostNicCardAddress = '127.0.0.1';
initializeStruct.HostNicCardAddress = '127.0.0.1';
initializeStruct.HostMulticastAddress = '225.1.1.1';
initializeStruct.TalkToClientsNicCardAddress = '0';
initializeStruct.ClientsMulticastAddress = '225.1.1.2';