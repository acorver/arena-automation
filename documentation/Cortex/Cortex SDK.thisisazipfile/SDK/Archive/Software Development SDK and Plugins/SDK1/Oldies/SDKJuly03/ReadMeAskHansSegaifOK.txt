SDK Readme  Software Development Kit for Motion Analysis RealTime system.  This allows
you to write a program that will request either marker or skeletion data and stream it
to your program in real time.  Your program can reside on the same computer as EVaRT or
on another computer that is connected via Ethernet.

This is intended as an overview of the SDK.  Contact support@Motionanalysis.com if you are
serious about this endeavor.

Revisions and dates shown below.............
=======================================================
The following is in the current version of EVaRT and the SDK
July 9 2003

EVaRT_Request(char *str);
EVaRT_RequestStartRecording();
EVaRT_RequestStopRecording();

The first request function is setup as a general parsable request 
     that has the following commands implemented.

         "LiveMode"
         "Pause"
         "SetOutputName=<FULL_TREENAME>"
         "GetContextFrameRate"

Note: The "SetOutputName=<FULL_TREENAME>"  should set both the 
     directory and the name simultaneously.


============================================
New in macRTcom.dll v114 Mar 24  2003
--------------------------------------------

Changed: A set of return values are now defined in EVaRT.h
         The functions return OK under normal usage.
         See the .h file for the list of return value defines.

         These return TRUE/FALSE:

             EVaRT_IsConnected()
             EVaRT_IsStreaming()

         This one is the exception:

             EVaRT_UDP_ReadNextFrame(...)   // Does anyone use this?

Added:   Functions to aid with Euler angle order.

             EVaRT_ConstructRotationMatrix(...)
             EVaRT_ExtractEulerAngles(...)


============================================
New in macRTcom.dll v113 Oct 1 2002
--------------------------------------------

New general request string:
    
        EVaRT_Request("GetContextFrameRate");

    This causes EVaRT to send the frame rate of the currently displayed data.
    This is a context sensitive result.

    The user function will get called with:

        datatype = CONTEXT_FRAME_RATE
        data = pointer to a float that has the frame rate.


============================================
New in macRTcom.dll v112 Nov 2 2001
--------------------------------------------

Bugfix:  When requesting names of things, if the list was empty,
         the DataHandler function was never called.
         This was when requesting:
		    Marker names
			Segment names
			Analog names
			DOF names


============================================
New in macRTcom.dll v111 Jun 18 2001
--------------------------------------------

New function:

    EVaRT_RequestDofNames();


Extended function:

    EVaRT_SetDataTypesWanted(...)

    Call this function with an OR of any of the following:

        TRC_DATA
	    GTR_DATA
	    HTR_DATA
	    ANALOG_DATA
        HTR2_DATA
		DOF_DATA

    e.g.  EVaRT_SetDataTypesWanted(DOF_DATA | ANALOG_DATA);


The data handler function will receive two new data types:

    DOF_NAMES     structure is sDofNames (similar to Marker and Segment names)
	DOF_DATA      structure is sDofFrame



============================================
New in macRTcom.dll v110 Mar 01 2001
--------------------------------------------

New function:

    EVaRT_RequestHierarchy2();

Purpose:
    This function is like EVaRT_RequestHierarchy() except that
	the hierarchy that comes across is the merged hierarchy of
	all the tracking objects.


Extended function:

    EVaRT_SetDataTypesWanted(...)

    The datatype HTR2_DATA has been added.  This data will be
	the merged HTR2 data of all the tracking objects.


============================================
New in macRTcom.dll v1xx Jan,  2001
--------------------------------------------


Analog data now gets sent from EVaRT via this SDK

New function:

    EVaRT_RequestAnalogNames();

Extended function:

    EVaRT_SetDataTypesWanted(...)

    Call this function with an OR of any of the following:

        TRC_DATA
	    GTR_DATA
	    HTR_DATA
	    ANALOG_DATA

    e.g.  EVaRT_SetDataTypesWanted(HTR_DATA | ANALOG_DATA);


The data handler function will receive two new data types:

    ANALOG_NAMES     structure is sAnalogNames (similar to Marker and Segment names)
	ANALOG_DATA      structure is sAnaFrame

----------------Sample code to set the output filename  -------------------

EVaRT_Initialize();

if(EVaRT_Connect("192.168.0.47") == OK)
{
  if(EVaRT_Request("SetOutputName=C:\\Temp\\Test.vc1") == OK )
  {
    TRACE("Filename Set");
  }
  else
  {
    TRACE("Filename Not Set");
  }
}
----------------code-------------------
