========================================================================
       DYNAMIC LINK LIBRARY : SDK2_DLL
========================================================================

========================================================================

Version 0.0.5 (June 6, 2005)
--------------

1) Bugfix:   When the client machine had two nic cards and the user initialized
             using one of the IP address (which they must do), there was
             a problem associated with a delay getting the associated name of
             the machine.


Version 0.0.4 (June 3, 2005)
--------------

1) Bugfix:   When the client or host machine had two nic cards, there was
             a problem associated with confirming an IP address as valid
             and existing.


Version 0.0.3 (May 31, 2005)
--------------

1) Bugfix:  There was a memory leak associated with EVaRT2_FreeFrame(...)

2) Bugfix:  The SDK now ignores data sent from machines other than the one
            the SDK is initialized for.

3) Bugfix:  Added a log message when EVaRT2_GetBodyDefs(...) gets no response
            from EVaRT.

4) Bugfix:  EVaRT2_Initialize(...) now returns RC_NetworkError when the
            szEVaNicCardAddress fails to decode.