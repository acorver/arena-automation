========================================================================
       DYNAMIC LINK LIBRARY : SDK2_DLL
========================================================================

========================================================================

Version 1.4.0 (Jan 26, 2011)

1) Feature: Added the function Cortex_ConfigurePortNumbers, so clients can set the port numbers for
            The sockets	used by the SDK.

Version 1.3.1 (Sep 10, 2010)
--------------

1) Bugfix:    If the host's (Cortex's) IP address wasn't specified there was an error establishing
              the connection.  Queries worked, but the info about the connection wasn't filled out.
              

Version 1.3.0 (Jul 22, 2010)
--------------

1) Added:    CameraTracker Zoom and Focus encoder values are sent with each frame


Version 1.2.2 (May 20, 2010)
--------------

1) Change:   Max bodies increased to 100 (Cortex still only sends 70)



Version 1.2.1 (Apr 12, 2010)
--------------

1) Added:    Cortex_SDK_static.lib
             This is the same as the DLL but can be linked in statically.
             


Version 1.2.1 (Feb 8, 2010)
--------------

1) Added:    Recording status is now part of each frame of data


Version 1.2.0 (December 21, 2009)
--------------

1) Change:   The name is changed to Cortex_SDK.dll

2) Added:    Angle encoder samples are now included in the Analog section
             of the data.
             
3) Added:    Six additional rotation orders are supported by the matrix functions:
                 XYX, XZX, YZY, YXY, ZXZ, ZYZ


Version 1.0.1 (March 22, 2006)
--------------

1) Bugfix:   The SDK2 used to start with a broadcast to find EVaRT.  It did this
             even if the initialize function specified the EVaRT IP address.


Version 1.0.0 (December 14, 2005)
--------------

1) Added:    Each frame of data from EVaRT is now stamped with a delay timestamp
             that gives the latency from the actual world action to the time of
             sending the frame of data.

2) Added:    Function to push a character's zero pose to EVaRT.

                 int EVaRT2_SendHtr(sHierarchy *pHierarchy, tSegmentData *pFrame)

             This function makes the SDK2 cover all the functionality in SDK1.


Version 0.0.7 (December 5, 2005)
--------------

1) Added:    Added matrix support functions for dealing with Euler angles.
             (These were in the SDK1)

                 void EVaRT2_ConstructRotationMatrix(...)
                 void EVaRT2_ExtractEulerAngles(...)


Version 0.0.6 (August 24, 2005)
--------------

1) Bugfix:   EVaRT2_FreeBodyDefs(...) freed all items within the structure
             but did not free the structure itself.  Now it does.


Version 0.0.5 (June 6, 2005)
--------------

1) Bugfix:   When the client machine had two nic cards and the user initialized
             using one of the IP address (which they must do), there was
             a problem associated with a delay getting the associated name of
             the machine.


Version 0.0.4 (June 3, 2005)
--------------

1) Bugfix:   When the client or host machine had two nic cards, there was
             a problem associated with confirming an IP address as valid
             and existing.


Version 0.0.3 (May 31, 2005)
--------------

1) Bugfix:  There was a memory leak associated with EVaRT2_FreeFrame(...)

2) Bugfix:  The SDK now ignores data sent from machines other than the one
            the SDK is initialized for.

3) Bugfix:  Added a log message when EVaRT2_GetBodyDefs(...) gets no response
            from EVaRT.

4) Bugfix:  EVaRT2_Initialize(...) now returns RC_NetworkError when the
            szEVaNicCardAddress fails to decode.