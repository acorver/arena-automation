
#ifndef STANDARD_H
#define STANDARD_H

#ifdef _WINDOWS

#define NT_COMPILE


// Visual Basic variation:
// The .DEF file enumerates the exported functions.
// All exported function (in the .DEF file) must have
// this stack convention.  (same as WINAPI)

#define EXPORTED __stdcall

#endif

#define LOCAL static
#define GLOBAL

#define TRUE 1
#define FALSE 0

#define U8  unsigned char
#define U16 unsigned short
#define U32 unsigned long
#define U64 unsigned long long

#define S8  char
#define S16 short
#define S32 long
#define S64 long long

#define F32 float
#define F64 double


// Use OK when there are various error possibilities
// Never compare variable to TRUE or ERRFLAG
// Use "if (iVar == OK)" or "if (iVar != OK)"
// Use "if (bVar)" or "if (!bVar)"

#define YES 1
#define NO 0
#define OK 0
#define CANCEL -1
#define ERRFLAG -1

#define PI 3.14159265358979
#define XEMPTY 9999999.0f
#define NO_PATH -1
#define IEMPTY -1

#define ABS(x) (((x)>0)?(x):-(x))
//#define MIN(x1,x2) (((x1)<(x2))?(x1):(x2))
//#define MAX(x1,x2) (((x1)>(x2))?(x1):(x2))

#define MAX_INT 0x7FFFFFFF
#define MIN_INT 0x80000000

#ifndef NULL
#define NULL 0
#endif

// [0]=Program, [1]=Major, [2]=Minor, [3]=Bugfix
extern const unsigned char MyVersionNumber[4];

extern char szExeDir[256];


void PopupNotice(char *szText, char *szTitle="EVa RealTime");
void PopupWarning(char *szText, char *szTitle="Warning");
void PopupError(char *szText, char *szTitle="ERROR");
int  OkCancel(char *sText, char *szTitle="EVa RealTime");
int  YesNoCancel(char *sText, char *szTitle="EVa RealTime");
int  YesNo(char *sText, char *szTitle="EVa RealTime");

extern "C"
{
int  MaCheckLicense(char *product);
}

int TrimLine(char *line);

//#define malloc(nBytes) MyMalloc(nBytes)
//#define free(ptr) MyFree(ptr)

void *MyMalloc(int nBytes);
void MyFree(void *ptr);

#endif
