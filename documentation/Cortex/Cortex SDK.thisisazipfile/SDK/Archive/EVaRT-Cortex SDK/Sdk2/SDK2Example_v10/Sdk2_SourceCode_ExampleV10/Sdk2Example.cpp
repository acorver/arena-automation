#include <windows.h>				// for Sleep() function
#include "EvartSdk2Interface.h"		// wrapper around EVaRT SDK2

#define APP_VERSION "1.0"

// Types of data to record
typedef enum
{
	IDENTIFIED_MKRS		= 0,
	UNIDENTIFIED_MKRS,
	SEGMENT_DATA,
	DOF_DATA,
	ANALOG_DATA,
	FORCE_DATA,

	DATA_TYPE_COUNT

} kDataTypes;

// Change these to zero if you don't want a file written for a particular data type
#define WRITE_IDENTIFIED_MKRS	1
#define WRITE_UNIDENTIFIED_MKRS	1
#define WRITE_SEGMENT_DATA		1
#define WRITE_DOF_DATA			1
#define WRITE_ANALOG_DATA		1
#define WRITE_FORCE_DATA		1
 
// This object has the ability to receive data from the
// EvartSdk2Interface object becuase it implements the
// ISdkDataListener interface. The two required methods
// for this interface are SdkDataHasArrived() and AcceptingSdkData()
class MySdk2Client : public ISdkDataListener
{
	
public:

	// Constructor
	MySdk2Client() : m_acceptData(false) 
	{
		for (int i = 0; i < DATA_TYPE_COUNT; i++) 
		{
			m_dataFiles[i] = NULL;
		}
	}

	// Destructor, must close the data files
	~MySdk2Client() 
	{
		for (int i = 0; i < DATA_TYPE_COUNT; i++)
		{
			if (m_dataFiles[i]) fclose(m_dataFiles[i]);
		}
	}

	// Required method to implement the ISdkDataListener interface.
	// Once we register ourselves with an EvartSdk2Interface object,
	// this method will be called whenever a frame of data arrives from
	// EVaRT.
	virtual void SdkDataHasArrived(sFrameOfData* data);

	// Required method to implement the ISdkDataListener interface.
	// This should return true if frames of data are currently being
	// accepted, and false if you do not want to receive frames of data.
	virtual bool AcceptingSdkData() const { return m_acceptData; } 

	// Connect to the EVaRT SDK2 running on "serverIP" using the NIC in
	// our client machine with IP address "clientIP"; maxFrames is the number
	// of frames to write to the data file before exiting.
	bool Connect(const char* serverIP, const char* clientIP, int maxFrames);

	// Have we received all the frames required
	bool IsFinished() const		{ return m_frameCount >= m_maxFrames; }
	
	// Unregister ourselves from the EvartSdk2Interface object
	void Disconnect()
	{
		m_sdk.SetDataListener(NULL);
		m_sdk.Uninitialize();
	}

	// Create a file for the given data type
	bool CreateDataFile(int dataType, const char* filename)
	{
		bool rc = false;

		if (dataType >= 0 && dataType < DATA_TYPE_COUNT)
		{
			m_dataFiles[dataType] = fopen(filename, "w");
			rc = (m_dataFiles[dataType] != NULL);
		}

		return rc;
	}

private:

	bool m_acceptData;
	int m_frameCount;
	int m_maxFrames;
	FILE* m_dataFiles[DATA_TYPE_COUNT];
	EvartSdk2Interface m_sdk;

	void WriteFileHeader(int dataType, sBodyDefs* bodyDefs);
	void WriteFrame(sFrameOfData* data);

	void WriteIdentifiedHeader(FILE* fp, sBodyDefs* bodyDefs);
	void WriteUnidentifiedHeader(FILE* fp, sBodyDefs* bodyDefs);
	void WriteSegmentHeader(FILE* fp, sBodyDefs* bodyDefs);
	void WriteDofHeader(FILE* fp, sBodyDefs* bodyDefs);
	void WriteAnalogHeader(FILE* fp, sBodyDefs* bodyDefs);
	void WriteForceHeader(FILE* fp, sBodyDefs* bodyDefs);

	void WriteIdentifiedFrame(FILE* fp, sFrameOfData* data);
	void WriteUnidentifiedFrame(FILE* fp, sFrameOfData* data);
	void WriteSegmentFrame(FILE* fp, sFrameOfData* data);
	void WriteDofFrame(FILE* fp, sFrameOfData* data);
	void WriteAnalogFrame(FILE* fp, sFrameOfData* data);
	void WriteForceFrame(FILE* fp, sFrameOfData* data);
};


int main(int argc, char** argv)
{
	MySdk2Client sdkClient;

	printf("*** Motion Analysis SDK2 Sample Program\n");
	printf("*** Program Version: %s\n", APP_VERSION);
	printf("*** SDK2 Version   : %s\n\n", EvartSdk2Interface::VersionString().c_str());

	if (argc != 4)
	{
		printf("Usage: Sdk2Example <EVaRT SDK2 IP Address> <client IP address> <frames to receive>\n");
		system("pause");
		return 0;
	}
	
	// Try to connect to the given EVaRT SDK2 server
	if (sdkClient.Connect(argv[1], argv[2], atoi(argv[3])))
	{
		printf("Streaming data from EVaRT SDK2 server %s...\n\n", argv[1]);
		
		// Just wait until we've received the required number of frames
		while (sdkClient.IsFinished() == false)
		{
			Sleep(1000);
		}
		sdkClient.Disconnect();

		printf("\n\nFinished\n");
	}
	else
	{
		printf("Could not connect to EVaRT SDK2 at %s\n", argv[1]);
	}

	return 0;
}

// This is called for each frame of data received by the SDK2.
// The pointer to data is "hot", so if it needs to be stored
// for later use, use EvartSdk2Interface::CopyFrame() to make a copy.
void MySdk2Client::SdkDataHasArrived(sFrameOfData* data)
{
	WriteFrame(data);

	// Stop accepting frames of data once we reach the number set by the user on the command line
	if (++m_frameCount == m_maxFrames)
	{
		m_acceptData = false;
	}

	if (m_frameCount % 10 == 0)
	{
		printf("Frames received: %d\r", m_frameCount);
	}
}

// Initialize the EVaRT SDK2
// Query list of objects being tracked by EVaRT
// Write out data file header
bool MySdk2Client::Connect(const char* serverIP, const char* clientIP, int maxFrames)
{
	bool rc;
	sBodyDefs* evartObjects = NULL;

	m_maxFrames = maxFrames;
	m_frameCount = 0;

	// Initialize the EVaRT SDK2
	rc = m_sdk.Initialize(clientIP, serverIP);
	
	// Query the list of objects that EVaRT is currently tracking
	evartObjects = m_sdk.GetBodyDefinitions();

	if (rc && evartObjects)
	{

#if WRITE_IDENTIFIED_MKRS
		if (CreateDataFile(IDENTIFIED_MKRS, "named_mkrs.csv"))
		{
			WriteFileHeader(IDENTIFIED_MKRS, evartObjects);
		}
#endif

#if WRITE_UNIDENTIFIED_MKRS
		if (CreateDataFile(UNIDENTIFIED_MKRS, "unnamed_mkrs.csv"))
		{
			WriteFileHeader(UNIDENTIFIED_MKRS, evartObjects);
		}
#endif

#if WRITE_SEGMENT_DATA
		if (CreateDataFile(SEGMENT_DATA, "segment_data.csv"))
		{
			WriteFileHeader(SEGMENT_DATA, evartObjects);
		}
#endif

#if WRITE_DOF_DATA
		if (CreateDataFile(DOF_DATA, "dof_data.csv"))
		{
			WriteFileHeader(DOF_DATA, evartObjects);
		}
#endif

#if WRITE_ANALOG_DATA
		if (CreateDataFile(ANALOG_DATA, "analog_data.csv"))
		{
			WriteFileHeader(ANALOG_DATA, evartObjects);
		}
#endif

#if WRITE_FORCE_DATA
		if (CreateDataFile(FORCE_DATA, "force_data.csv"))
		{
			WriteFileHeader(FORCE_DATA, evartObjects);
		}
#endif		
		// Register ourselves as a listener
		m_sdk.SetDataListener(this);
		
		// We are now ready to accept frames of data from EVaRT
		m_acceptData = true;
	}
	else
	{
		rc = false;
	}

	// Free memory for the EVaRT body definitions
	m_sdk.FreeBodyDefinitions(evartObjects);

	return rc;
}


// Write out a file header for the given data type
void MySdk2Client::WriteFileHeader(int dataType, sBodyDefs* bodyDefs)
{
	if (dataType < 0) return;
	if (dataType >= DATA_TYPE_COUNT) return;
	if (m_dataFiles[dataType] == NULL) return;

	FILE* fp = m_dataFiles[dataType];

	switch (dataType)
	{
	case IDENTIFIED_MKRS:
		WriteIdentifiedHeader(fp, bodyDefs);
		break;

	case UNIDENTIFIED_MKRS:
		WriteUnidentifiedHeader(fp, bodyDefs);
		break;

	case SEGMENT_DATA:
		WriteSegmentHeader(fp, bodyDefs);
		break;

	case DOF_DATA:
		WriteDofHeader(fp, bodyDefs);
		break;

	case ANALOG_DATA:
		WriteAnalogHeader(fp, bodyDefs);
		break;

	case FORCE_DATA:
		WriteForceHeader(fp, bodyDefs);
		break;

	default:
		break;
	}
}

void MySdk2Client::WriteFrame(sFrameOfData* data)
{
	if (m_dataFiles[IDENTIFIED_MKRS])
	{
		WriteIdentifiedFrame(m_dataFiles[IDENTIFIED_MKRS], data);
	}
	if (m_dataFiles[UNIDENTIFIED_MKRS])
	{
		WriteUnidentifiedFrame(m_dataFiles[UNIDENTIFIED_MKRS], data);
	}
	if (m_dataFiles[SEGMENT_DATA])
	{
		WriteSegmentFrame(m_dataFiles[SEGMENT_DATA], data);
	}
	if (m_dataFiles[DOF_DATA])
	{
		WriteDofFrame(m_dataFiles[DOF_DATA], data);
	}
	if (m_dataFiles[ANALOG_DATA])
	{
		WriteAnalogFrame(m_dataFiles[ANALOG_DATA], data);
	}
	if (m_dataFiles[FORCE_DATA])
	{
		WriteForceFrame(m_dataFiles[FORCE_DATA], data);
	}
}


void MySdk2Client::WriteIdentifiedHeader(FILE* fp, sBodyDefs* bodyDefs)
{
	int i, j;

	fprintf(fp, "Markers:");
	
	// Write out all of the marker names
	for (i = 0; i < bodyDefs->nBodyDefs; i++)
	{
		for (j = 0; j < bodyDefs->BodyDefs[i].nMarkers; j++)
		{
			fprintf(fp, ",%s,,", bodyDefs->BodyDefs[i].szMarkerNames[j]);
		}
	}
	
	fprintf(fp, "\nFrame#");
	
	// Make columns for X, Y, Z for each marker
	for (i = 0; i < bodyDefs->nBodyDefs; i++)
	{
		for (j = 0; j < bodyDefs->BodyDefs[i].nMarkers; j++)
		{
			char* name = bodyDefs->BodyDefs[i].szMarkerNames[j];
			fprintf(fp, ",%s_X,%s_Y,%s_Z", name, name, name);
		}
	}
	fprintf(fp, "\n");
}

void MySdk2Client::WriteUnidentifiedHeader(FILE* fp, sBodyDefs* bodyDefs)
{
	const int MAX_UNNAMED = 50;
	const char* name = "Unnamed";
	int i;

	fprintf(fp, "Markers:");
	
	// Make room for MAX_UNNAMED marker slots
	for (i = 0; i < MAX_UNNAMED; i++)
	{
		fprintf(fp, ",%s%d,,", name, i);
	}
	
	fprintf(fp, "\nFrame#");
	
	// Make columns for X, Y, Z for each marker
	for (i = 0; i < MAX_UNNAMED; i++)
	{
		fprintf(fp, ",%s%d_X,%s%d_Y,%s%d_Z", name, i, name, i, name, i);
	}
	fprintf(fp, "\n");	
}

void MySdk2Client::WriteSegmentHeader(FILE* fp, sBodyDefs* bodyDefs)
{
	int i, j;

	// Write out the segment hierarchy
	fprintf(fp, "CHILD,PARENT\n");

	for (i = 0; i < bodyDefs->nBodyDefs; i++)
	{
		for (j = 0; j < bodyDefs->BodyDefs[i].Hierarchy.nSegments; j++)
		{
			char* child = bodyDefs->BodyDefs[i].Hierarchy.szSegmentNames[j];
			int parentIndex = bodyDefs->BodyDefs[i].Hierarchy.iParents[j];
			char* parent = parentIndex >= 0 ? bodyDefs->BodyDefs[i].Hierarchy.szSegmentNames[parentIndex] : "GLOBAL";

			fprintf(fp, "%s,%s\n", child, parent);
		}
	}
	fprintf(fp, "\n\n");

	fprintf(fp, "Segments:");
	
	// Write out all of the segment names
	for (i = 0; i < bodyDefs->nBodyDefs; i++)
	{
		for (j = 0; j < bodyDefs->BodyDefs[i].Hierarchy.nSegments; j++)
		{
			fprintf(fp, ",%s,,,,,,", bodyDefs->BodyDefs[i].Hierarchy.szSegmentNames[j]);
		}
	}
	
	fprintf(fp, "\nFrame#");
	
	// Make columns for TX, TY, TZ, RX, RY, RZ, Length
	for (i = 0; i < bodyDefs->nBodyDefs; i++)
	{
		for (j = 0; j < bodyDefs->BodyDefs[i].Hierarchy.nSegments; j++)
		{
			char* name = bodyDefs->BodyDefs[i].Hierarchy.szSegmentNames[j];
			fprintf(fp, ",%s_TX,%s_TY,%s_TZ,%s_RX,%s_RY,%s_RZ,%s_Len", name, name, name, name, name, name, name);
		}
	}
	fprintf(fp, "\n");
}

void MySdk2Client::WriteDofHeader(FILE* fp, sBodyDefs* bodyDefs)
{
	int i, j;

	fprintf(fp, "Frame#");
	
	// Write out all of the DOF names
	for (i = 0; i < bodyDefs->nBodyDefs; i++)
	{
		for (j = 0; j < bodyDefs->BodyDefs[i].nDofs; j++)
		{
			fprintf(fp, ",%s", bodyDefs->BodyDefs[i].szDofNames[j]);
		}
	}
	
	fprintf(fp, "\n");
}

void MySdk2Client::WriteAnalogHeader(FILE* fp, sBodyDefs* bodyDefs)
{
	int i;

	fprintf(fp, "Frame#,Sample#");
	
	// Write out all of the analog channel names
	for (i = 0; i < bodyDefs->nAnalogChannels; i++)
	{
		fprintf(fp, ",%s", bodyDefs->szAnalogChannelNames[i]);
	}
	
	fprintf(fp, "\n");
}

void MySdk2Client::WriteForceHeader(FILE* fp, sBodyDefs* bodyDefs)
{
	const char* names[] = {"X", "Y", "Z", "fX", "fY", "fZ", "mZ"};
	int i;

	fprintf(fp, "Frame#,Sample#");
	
	// Write out all of the force plate channel names
	for (i = 0; i < bodyDefs->nForcePlates; i++)
	{
		for (int j = 0; j < 7; j++)
		{
			fprintf(fp, ",FP%d_%s", i+1, names[j]);
		}
	}
	
	fprintf(fp, "\n");
}

void MySdk2Client::WriteIdentifiedFrame(FILE* fp, sFrameOfData* data)
{
	// Write out frame number
	fprintf(fp, "%d", data->iFrame);
	
	// Write out X, Y, Z for each marker
	for (int i = 0; i < data->nBodies; i++)
	{
		for (int j = 0; j < data->BodyData[i].nMarkers; j++)
		{
			if (data->BodyData[i].Markers[j][0] < XEMPTY)
			{
				fprintf(fp, ",%f,%f,%f",
					data->BodyData[i].Markers[j][0],
					data->BodyData[i].Markers[j][1],
					data->BodyData[i].Markers[j][2]);

			}
			else
			{
				fprintf(fp, ",%f,%f,%f",
					0.0,
					0.0,
					0.0);
			}
		}
	}
	fprintf(fp, "\n");
}

void MySdk2Client::WriteUnidentifiedFrame(FILE* fp, sFrameOfData* data)
{
	// Write out frame number
	fprintf(fp, "%d", data->iFrame);
	
	// Write out X, Y, Z for each unnamed marker
	for (int i = 0; i < data->nUnidentifiedMarkers; i++)
	{
		fprintf(fp, ",%f,%f,%f",
				data->UnidentifiedMarkers[i][0],
				data->UnidentifiedMarkers[i][1],
				data->UnidentifiedMarkers[i][2]);
	}
	fprintf(fp, "\n");
}

void MySdk2Client::WriteSegmentFrame(FILE* fp, sFrameOfData* data)
{
	// Write out frame number
	fprintf(fp, "%d", data->iFrame);
	
	// Write out TX, TY, TZ, RX, RY, RZ, Length for each segment
	for (int i = 0; i < data->nBodies; i++)
	{
		for (int j = 0; j < data->BodyData[i].nSegments; j++)
		{
			if (data->BodyData[i].Segments[j][0] < XEMPTY)
			{
				fprintf(fp, ",%f,%f,%f,%f,%f,%f,%f",
					data->BodyData[i].Segments[j][0],
					data->BodyData[i].Segments[j][1],
					data->BodyData[i].Segments[j][2],
					data->BodyData[i].Segments[j][3],
					data->BodyData[i].Segments[j][4],
					data->BodyData[i].Segments[j][5],
					data->BodyData[i].Segments[j][6]);
			}
			else
			{
				fprintf(fp, ",%f,%f,%f,%f,%f,%f,%f",
					0.0,
					0.0,
					0.0,
					0.0,
					0.0,
					0.0,
					0.0);
			}
		}
	}
	fprintf(fp, "\n");
}

void MySdk2Client::WriteDofFrame(FILE* fp, sFrameOfData* data)
{
	// Write out frame number
	fprintf(fp, "%d", data->iFrame);
	
	// Write out value for each dof
	for (int i = 0; i < data->nBodies; i++)
	{
		for (int j = 0; j < data->BodyData[i].nDofs; j++)
		{
			if (data->BodyData[i].Dofs[j] < XEMPTY)
			{
				fprintf(fp, ",%f", data->BodyData[i].Dofs[j]);

			}
			else
			{
				fprintf(fp, ",%f", 0.0);
			}
		}
	}
	fprintf(fp, "\n");
}

void MySdk2Client::WriteAnalogFrame(FILE* fp, sFrameOfData* data)
{
	static int sample = 0;
	int nChannels = data->AnalogData.nAnalogChannels;
	int nSamples = data->AnalogData.nAnalogSamples;

	// Write out frame number
	fprintf(fp, "%d", data->iFrame);

	for (int i = 0; i < nSamples; i++)
	{
		// Write out sample number
		fprintf(fp, ",%d", sample++);
	
		// Write out data for each channel
		for (int j = 0; j < nChannels; j++)
		{
			fprintf(fp, ",%hd", data->AnalogData.AnalogSamples[i*nChannels + j]);
		}

		if (i != nSamples - 1) fprintf(fp, "\n");
	}

	fprintf(fp, "\n");
}

void MySdk2Client::WriteForceFrame(FILE* fp, sFrameOfData* data)
{
	static int sample = 0;
	int nPlates = data->AnalogData.nForcePlates;
	int nSamples = data->AnalogData.nForceSamples;

	// Write out frame number
	fprintf(fp, "%d", data->iFrame);

	for (int i = 0; i < nSamples; i++)
	{
		// Write out sample number
		fprintf(fp, ",%d", sample++);
	
		// Write out data for each plate
		for (int j = 0; j < nPlates; j++)
		{
			fprintf(fp, ",%f,%f,%f,%f,%f,%f,%f",
				data->AnalogData.Forces[i*nPlates + j][0],
				data->AnalogData.Forces[i*nPlates + j][1],
				data->AnalogData.Forces[i*nPlates + j][2],
				data->AnalogData.Forces[i*nPlates + j][3],
				data->AnalogData.Forces[i*nPlates + j][4],
				data->AnalogData.Forces[i*nPlates + j][5],
				data->AnalogData.Forces[i*nPlates + j][6]);
		}

		if (i != nSamples - 1) fprintf(fp, "\n");
	}

	fprintf(fp, "\n");
}