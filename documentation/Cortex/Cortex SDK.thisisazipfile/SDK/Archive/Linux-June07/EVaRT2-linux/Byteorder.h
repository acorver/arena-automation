#ifndef _BYTEORDER_H_
#define _BYTEORDER_H_
/*
 *  Byteorder.h
 *
 *  Created by Loren Olson on 11/11/05.
 *
 */

/*
 * The following SWAP macros handle Network byteorder issues.
 * On Windows, we don't need to do anything, but on the Mac,
 * all the data needs to be swapped.
 *
 * TODO: it has just occured to me, that with the Apple switch
 * to Intel taking place, the check for Mac needs to be more
 * specific - needs to check for PowerPC CPU.
 *
 */

#ifdef __LITTLE_ENDIAN__

#define SWAP_SHORT(x)		(x)
#define SWAP_LONG(x)		(x)
#define SWAP_FLOAT(x)		(x)
#define SWAP_DOUBLE(x)		(x)

#else

// #include <machine/byte_order.h>

static __inline__
double ameSwapDouble( double inv )
{
    union doubleconv {
		double				ud;
		unsigned char		uc[8];
    } *inp, outv;
    
    inp = (union doubleconv *)&inv;
    
    outv.uc[0] = inp->uc[7];
    outv.uc[1] = inp->uc[6];
    outv.uc[2] = inp->uc[5];
    outv.uc[3] = inp->uc[4];
    outv.uc[4] = inp->uc[3];
    outv.uc[5] = inp->uc[2];
    outv.uc[6] = inp->uc[1];
    outv.uc[7] = inp->uc[0];
    
    return( outv.ud );
}

static __inline__
float ameSwapFloat( float inv )
{
    union floatconv {
		float				uf;
		unsigned char		uc[4];
    } *inp, outv;
    
    inp = (union floatconv *)&inv;
    
    outv.uc[0] = inp->uc[3];
    outv.uc[1] = inp->uc[2];
    outv.uc[2] = inp->uc[1];
    outv.uc[3] = inp->uc[0];
    
    return( outv.uf );
}

static __inline__
long ameSwapLong( long inv )
{
    union longconv {
		long				ul;
		unsigned char		uc[8];
    } *inp, outv;
    
    inp = (union longconv *)&inv;
    
    outv.uc[0] = inp->uc[7];
    outv.uc[1] = inp->uc[6];
    outv.uc[2] = inp->uc[5];
    outv.uc[3] = inp->uc[4];
    outv.uc[4] = inp->uc[3];
    outv.uc[5] = inp->uc[2];
    outv.uc[6] = inp->uc[1];
    outv.uc[7] = inp->uc[0];
    
    return( outv.ul );
}

static __inline__
short ameSwapShort( short inv )
{
    union shortconv {
		short				us;
		unsigned char		uc[2];
    } *inp, outv;
    
    inp = (union shortconv *)&inv;
    
    outv.uc[0] = inp->uc[1];
    outv.uc[1] = inp->uc[0];
    
    return( outv.us );
}

#define SWAP_SHORT(x)		ameSwapShort(x)
#define SWAP_LONG(x)		ameSwapLong(x)
#define SWAP_FLOAT(x)		ameSwapFloat(x)
#define SWAP_DOUBLE(x)		ameSwapDouble(x)

#endif


#endif          /* _MULTICASTCOMMON_H_ */
