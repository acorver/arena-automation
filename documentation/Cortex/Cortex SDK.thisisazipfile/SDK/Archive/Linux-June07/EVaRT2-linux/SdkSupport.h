
// This is the NEW set of commands that EVaRT is listening for on port 1504


// Generic handshake either way

#define PKT2_HELLO_WORLD            0  // Broadcast
#define PKT2_ARE_YOU_THERE          1  // Directed query
#define PKT2_HERE_I_AM              2
#define PKT2_COMMENT                3

#define PKT2_REQUEST_BODYDEFS      10
#define PKT2_BODYDEFS              11

#define PKT2_REQUEST_FRAME         12
#define PKT2_FRAME_OF_DATA         13

#define PKT2_GENERAL_REQUEST       14
#define PKT2_GENERAL_REPLY         15
#define PKT2_UNRECOGNIZED_REQUEST  16

#define PKT2_UNRECOGNIZED_COMMAND  0x5678


// To Client

#define MESSAGE_BEGIN_RECORDING    33
#define MESSAGE_END_RECORDING      34


// From Client

#define REQUEST_START_RECORDING       0x0180
#define REQUEST_STOP_RECORDING        0x0181

#define REQUEST_FRAME                 0x0200 // This is for polling and testing


#ifndef _WINDOWS
typedef int SOCKET;
#define INVALID_SOCKET 		-1
#define SOCKET_ERROR 		-1
typedef void *          HANDLE;
typedef unsigned long   DWORD;
#define WINAPI
#define Sleep           usleep
#define THREAD_FUNC     void *
#define closesocket		close
#endif


typedef struct sMe
{
    char          szName[128];
    unsigned char Version[4];

} sMe;



typedef struct sPacket
{
    unsigned short iCommand;
    unsigned short nBytes;
    union
    {
        sMe           Me;
        char          String[256];
        unsigned char ucData[0x10000];
        char          cData[0x10000];
    } Data;

} sPacket;

//extern sPacket PacketOut;
//extern sPacket PacketIn;

void LogMessage(int iLevel, char *szMsg);

int ConvertToIPAddress(char *szNameOrAddress, struct in_addr *Address);
SOCKET Socket_CreateLargeMultiCast(in_addr MyAddress, int MyPort, in_addr MultiCastAddress);
int ProcessSocketError();
int EVaRT2_GetAllOfMyAddresses(unsigned long Addresses[], int nMax);
#ifdef NT_COMPILE
// This extern prototype conflicts with the static prototype in EVaRT2.cpp - generates GCC Error
int GetHostByAddr(unsigned char Address[4], char szName[]);
#endif
