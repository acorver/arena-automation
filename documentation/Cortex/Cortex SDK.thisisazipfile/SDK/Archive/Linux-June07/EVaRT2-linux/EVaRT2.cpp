/*=========================================================
//
// File: EVaRT2.cpp  v200
//
// Created by Ned Phipps, Oct-2004
//
=============================================================================*/

/*! \file EVaRT2.cpp
This file implements the API for ethernet communication of data
between EVaRT and multiple client programs.
*/

#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>
#include <sys/errno.h>
// #include <Carbon/Carbon.h> (CL)

#include <stdio.h>
#include <time.h>

#include "EVaRT2.h" 	// Users will include this header

#include "standard.h"

#include "SdkSupport.h"
#include "Byteorder.h"

const unsigned char MyVersionNumber[4] = {4,0,0,6}; // ProgramID, Major, Minor, Bugfix

LOCAL int         bInitialized = FALSE;
LOCAL sHostInfo   HostInfo;
LOCAL int         User_VerbosityLevel = VL_Debug;

SOCKET Socket_CreateForBroadcasting(unsigned long IP_Address, unsigned short uPort);
int    Broadcast(SOCKET sockfd, unsigned short uPort, char *Buffer, int nBytes);
LOCAL int SendToEVa(sPacket *Packet);
LOCAL int GetHostByAddr(unsigned char Address[4], char szName[]);
LOCAL void GetHostName_ASYNC();


LOCAL sBodyDefs* Unpack_BodyDefs(char *Data, int nBytes);
LOCAL int Unpack_FrameOfData(char *Data, int nTotalBytes, sFrameOfData *Frame);

LOCAL sBodyDefs* pNewBodyDefs = NULL;

LOCAL sPacket PacketOut;
LOCAL sPacket PacketIn_Frame;
LOCAL sPacket PacketIn;

#ifdef THIS_IS_NOT_USED
//  this is currently not used?
LOCAL char *pBodyDefBuffer=NULL; // Gets allocated the same size as the received packet.
#endif
LOCAL sFrameOfData LatestFrameOfData;
LOCAL sFrameOfData Polled_FrameOfData;


//LOCAL  unsigned short wMyPort = 1600;         // My outgoing port (EVa auto-replies to me here)
LOCAL  unsigned short wMyPort = 1510;         	// My outgoing port (EVa auto-replies to me here)
//LOCAL  unsigned short wMyPort = 0;            // Let the socket library find an available port

LOCAL  unsigned short wEVaPort = 1510;        	// EVa is listening at this port
//LOCAL  unsigned short wMultiCastPort = 1001;  // EVa sends frames to this port and associated address
LOCAL  unsigned short wMultiCastPort = 5678;  	// EVa sends frames to this port and associated address


// this is easier for the moment, but we shouldn't init this value two different ways...
#define MULTICAST_ADDRESS_STR "225.1.1.1"
// under Mac OS X 10.4 with GCC 4.0, the above initialization doesn't work.
// (perhaps because this struct is an unsigned int)
// This alternate version is a bit obtuse, but it seems to work for now.
LOCAL  in_addr MyNicCardAddress  = { (192 << 24) + (168 << 16) + (1 << 8) + 11 };   // My local IP address
LOCAL  in_addr MultiCastAddress  = { (225 << 24) + (  1 << 16) + (1 << 8) +  1 };   // EVa sends frames to this address and associated port
LOCAL  in_addr EVaNicCardAddress = { (192 << 24) + (168 << 16) + (1 << 8) + 14 };


LOCAL  sockaddr_in EVaAddr;                   // This gets filled out when EVaRT replies.


LOCAL  SOCKET CommandSocket = -1;
LOCAL  SOCKET MultiCastReaderSocket = -1;


// For use with waiting for replies from EVaRT.
LOCAL  sem_t		    EH_CommandConfirmed;

LOCAL  pthread_t        EVaListenThread_ID;
LOCAL  THREAD_FUNC      EVaListenThread_Func(void * dummy);
LOCAL  HANDLE           EVaListenThread_Handle=NULL;

LOCAL  pthread_t        ReadDataThread_ID;
LOCAL  THREAD_FUNC      ReadDataThread_Func(void * dummy);
LOCAL  HANDLE           ReadDataThread_Handle=NULL;

LOCAL  pthread_t        GetHostNameThread_ID;
//LOCAL  THREAD_FUNC    GetHostNameThread_Func(void * dummy);
//LOCAL  HANDLE         GetHostNameThread_Handle=NULL;


//=============================================================================

LOCAL void Dummy_CB_DataHandler(sFrameOfData *FrameOfData){}
LOCAL void (*CB_DataHandler)(sFrameOfData *FrameOfData) = Dummy_CB_DataHandler;

//=============================================================================

LOCAL void Dummy_CB_ErrorMsgHandler(int iLevel, char *szMessage){}
LOCAL void (*CB_ErrorMsgHandler)(int iLevel, char *szMessage) = Dummy_CB_ErrorMsgHandler;

//=============================================================================

LOCAL int Broadcast(sPacket *Packet)
{
   return Broadcast(CommandSocket, wEVaPort, (char *)Packet, Packet->nBytes + 4);
}

//===================================================================
//-------------------------------------------------------------------

void LogMessage(int iLevel, char *szMsg)
{
    if (iLevel <= User_VerbosityLevel)
    {
        CB_ErrorMsgHandler(iLevel, szMsg);
    }
}

void FoundHost()
{
    char str[256];
    HostInfo.bFoundHost = TRUE;

//    sprintf("Found %s Version %d.%d.%d at %d.%d.%d.%d (%s)\n",
    sprintf(str, "AutoConnected to: %s Version %d.%d.%d at %d.%d.%d.%d (%s)",
        HostInfo.szHostProgramName,
        HostInfo.HostProgramVersion[1],
        HostInfo.HostProgramVersion[2],
        HostInfo.HostProgramVersion[3],

        HostInfo.HostMachineAddress[0],
        HostInfo.HostMachineAddress[1],
        HostInfo.HostMachineAddress[2],
        HostInfo.HostMachineAddress[3],
        HostInfo.szHostMachineName);

    LogMessage(VL_Info, str);
}


//===================================================================
//-------------------------------------------------------------------

LOCAL THREAD_FUNC EVaListenThread_Func(void * dummy)
{
    //hostent *pHostEnt;
    socklen_t addr_len;
    int nBytesReceived;
    int Count=0;
    char str[256];
    sockaddr_in TheirAddress;

    //memset(&EVaAddr, 0, sizeof(sockaddr_in));
    addr_len = sizeof(struct sockaddr);

    while (1)
    {
     // Block further processing until we receive a datagram from anyone,
     // including ourself, over the network.
     // This thread will spend most if its time asleep in this recvfrom
     // function.

        nBytesReceived = recvfrom(
            CommandSocket,
            (char *)&PacketIn,
            sizeof(sPacket),
            0,
            (struct sockaddr *)&TheirAddress,
            &addr_len);
		
        Count++;

        if (memcmp(&TheirAddress.sin_addr, HostInfo.HostMachineAddress, 4) == 0)
        {
#if 0
            if (!HostInfo.bFoundHost)
            {
                FoundHost();
            }
#endif
			LogMessage(VL_Debug, "Packet return address matches Eva address");
            HostInfo.LatestConfirmationTime = clock();
        }

        sprintf( str, "CommandReplyReader received from %s: Command=%d, nBytes=%d", 
                 inet_ntoa(TheirAddress.sin_addr), (int)SWAP_SHORT(PacketIn.iCommand), (int)PacketIn.nBytes );
        LogMessage(VL_Debug, str);

     	// First send SerialCommand Confirmation

     	// Now handle the data

        switch (SWAP_SHORT(PacketIn.iCommand))
        {
            case PKT2_HELLO_WORLD:
                sprintf(str, "HELLO_WORLD: %s, Version %d.%d.%d",
                    PacketIn.Data.Me.szName,
                    //PacketIn.Data.Me.Version[0],
                    PacketIn.Data.Me.Version[1],
                    PacketIn.Data.Me.Version[2],
                    PacketIn.Data.Me.Version[3]);
                LogMessage(VL_Debug, str);
                break;

            case PKT2_HERE_I_AM:
				
                if (*(unsigned long*)HostInfo.HostMachineAddress != 0
                 && *(unsigned long*)HostInfo.HostMachineAddress != TheirAddress.sin_addr.s_addr)
                {
                    LogMessage(VL_Debug, "Ignoring HERE_I_AM message from another machine");
                    break;
                }
				LogMessage(VL_Debug, "HERE_I_AM message");

                EVaAddr = TheirAddress;

                strcpy(HostInfo.szHostProgramName, PacketIn.Data.Me.szName);
                memcpy(HostInfo.HostProgramVersion, PacketIn.Data.Me.Version, 4);
                memcpy(HostInfo.HostMachineAddress, &EVaAddr.sin_addr.s_addr, 4);

				// This doesn't seem vital, and on Mac OS X, it causes a bus error.
                GetHostName_ASYNC();
				if (!HostInfo.bFoundHost)
                {
                    FoundHost();
                }

#if 0
                sprintf(str, "HERE_I_AM: %s, Version %d.%d.%d",
                    PacketIn.Data.Me.szName,
                    //PacketIn.Data.Me.Version[0],
                    PacketIn.Data.Me.Version[1],
                    PacketIn.Data.Me.Version[2],
                    PacketIn.Data.Me.Version[3]);
                LogMessage(VL_Debug, str);
#endif
                break;

            case PKT2_BODYDEFS:
                pNewBodyDefs = Unpack_BodyDefs(PacketIn.Data.cData, PacketIn.nBytes);
				sem_post(&EH_CommandConfirmed);
                break;

            case PKT2_FRAME_OF_DATA:
				Unpack_FrameOfData(PacketIn.Data.cData, PacketIn.nBytes, &Polled_FrameOfData); //CB_DataHandler(&Polled_FrameOfData);
				sem_post(&EH_CommandConfirmed);
                break;

            case PKT2_GENERAL_REPLY:
				sem_post(&EH_CommandConfirmed);
                break;

            case PKT2_UNRECOGNIZED_REQUEST:
				sem_post(&EH_CommandConfirmed);
                break;

            case PKT2_UNRECOGNIZED_COMMAND:
				sem_post(&EH_CommandConfirmed);
                break;

            case PKT2_COMMENT:
                sprintf(str, "COMMENT: %s\n", PacketIn.Data.String);
                LogMessage(VL_Debug, str);
                break;
			
			default:
				sprintf( str, "CommandReplyReader, unexpected value, PacketIn.iCommand== %d\n", SWAP_SHORT( PacketIn.iCommand ) );
				LogMessage(VL_Error, str );
				break;
        }
    }

 // Unreachable

	return 0;
}

#if 0
int TestRead(SOCKET socket)
{
    sockaddr TheirAddress;
    socklen_t addr_len;
    int nBytesReceived;
    //int Count=0;
	
    memset(&TheirAddress, 0, sizeof(sockaddr));
	
    addr_len = sizeof(struct sockaddr);
	
	// Block further processing until we receive a datagram from anyone,
	
    nBytesReceived = recvfrom(
							  socket,
							  (char *)&PacketIn,
							  sizeof(sPacket),
							  0,
							  &TheirAddress,
							  &addr_len);
	
	
    return nBytesReceived;
}
#endif

//===================================================================
//-------------------------------------------------------------------

LOCAL THREAD_FUNC ReadDataThread_Func(void * dummy)
{
    char str[256];
    sockaddr_in TheirAddress;
    socklen_t addr_len;
    int nBytesReceived;
    int Count=0;
	
	//  static SOCKET MultiCastReaderSocket = -1; // external for closing the socket
    if (MultiCastReaderSocket != -1)
    {
        //closesocket(MultiCastReaderSocket);
        MultiCastReaderSocket = -1;
    }

    MultiCastReaderSocket = Socket_CreateLargeMultiCast(
        MyNicCardAddress,
        wMultiCastPort,
        MultiCastAddress);

    if (MultiCastReaderSocket == -1)
    {
        LogMessage(VL_Error, "Unable to initialize FrameReader");
        return 0;
    }

	// TestRead(MultiCastReaderSocket);

    memset(&TheirAddress, 0, sizeof(sockaddr));
    memset(&LatestFrameOfData, 0, sizeof(sFrameOfData));

    while (1)
    {
        addr_len = sizeof(struct sockaddr);

     // Block further processing until we receive a datagram from anyone,
     // including ourself, over the network.
     // This thread should spend most if its time asleep in this recvfrom
     // function.

        nBytesReceived = recvfrom(
            MultiCastReaderSocket,
            (char *)&PacketIn_Frame,
            sizeof(sPacket),
            0,
            (sockaddr *)&TheirAddress,
            &addr_len);
		
        Count++;

        if (memcmp(&TheirAddress.sin_addr.s_addr, HostInfo.HostMachineAddress, 4) == 0)
        {
	        // Officially? found on the OTHER socket, since that's where we make the requests.
            if (!HostInfo.bFoundHost)
            {
                FoundHost();
            }
            //HostInfo.bFoundHost = TRUE;
			LogMessage(VL_Debug, "MultiCast packet return address matches Eva address");
            HostInfo.LatestConfirmationTime = clock();
        }
        else
        {
            sprintf(str, "MultiCastReader Ignoring packet from %s", inet_ntoa(TheirAddress.sin_addr) );
            LogMessage(VL_Debug, str);
            continue;
        }

        sprintf(str, "MultiCastReader Received From %s: Command=%d, nBytes=%d",
        	    inet_ntoa(TheirAddress.sin_addr), (int)SWAP_SHORT(PacketIn_Frame.iCommand), (int)PacketIn_Frame.nBytes);
        LogMessage(VL_Debug, str);


     // First send SerialCommand Confirmation

     // Now handle the data

        switch (SWAP_SHORT(PacketIn_Frame.iCommand))
        {
            case PKT2_FRAME_OF_DATA:
                Unpack_FrameOfData(PacketIn_Frame.Data.cData, PacketIn_Frame.nBytes, &LatestFrameOfData);
                CB_DataHandler(&LatestFrameOfData);
                break;

            case PKT2_HELLO_WORLD:
            case PKT2_HERE_I_AM:
                if (PacketIn_Frame.Data.Me.Version[0] != 1) // Not from EVaRT: Ignore it
                    break;

                if (HostInfo.HostMachineAddress[0] == 0)
                {

                    EVaAddr.sin_addr.s_addr = TheirAddress.sin_addr.s_addr;

                    memcpy(&HostInfo.HostMachineAddress, &TheirAddress.sin_addr.s_addr, 4);
                    strcpy(HostInfo.szHostProgramName, PacketIn_Frame.Data.Me.szName);
                    memcpy(&HostInfo.HostProgramVersion, PacketIn_Frame.Data.Me.Version, 4);

                    GetHostName_ASYNC();
                    if (!HostInfo.bFoundHost)
                    {
                        FoundHost();
                    }
#if 0
                    HostInfo.bFoundHost = TRUE;

                    sprintf(str, "AutoConnected to: %s Version %d.%d.%d at %d.%d.%d.%d (%s)",
                        HostInfo.szHostProgramName,
                        HostInfo.HostProgramVersion[1],
                        HostInfo.HostProgramVersion[2],
                        HostInfo.HostProgramVersion[3],
                        HostInfo.HostMachineAddress[0],
                        HostInfo.HostMachineAddress[1],
                        HostInfo.HostMachineAddress[2],
                        HostInfo.HostMachineAddress[3],
                        HostInfo.szHostMachineName);

                    LogMessage(VL_Info, str);
#endif
                }
                break;

            case PKT2_COMMENT:
                sprintf(str, "DataStream Comment: %s\n", PacketIn_Frame.Data.String);
                LogMessage(VL_Debug, str);
                break;
        }
    }

 // Unreachable

	return 0;
}

//===================================================================
//-------------------------------------------------------------------

LOCAL int Initialize_ListenForReplies()
{
    char str[256];

    if (CommandSocket != -1)
    {
		// ???
		LogMessage(VL_Error, "Initialize_ListenForReplies CommandSocket != -1\n");
        return OK;
    }

    CommandSocket = Socket_CreateForBroadcasting(MyNicCardAddress.s_addr, wMyPort);
    if (CommandSocket == -1)
    {
        LogMessage(VL_Error, "Unable to initialize SDK Sockets.");
        return RC_NetworkError;
    }

	// Large 1MB Buffer for receiving so we don't lose data.
	#define SO_RCVBUFF_TARGET_SIZE 0x100000
	int optval = SO_RCVBUFF_TARGET_SIZE;
	socklen_t optval_size = 4;
    setsockopt(CommandSocket, SOL_SOCKET, SO_RCVBUF, (char *)&optval, 4);
    getsockopt(CommandSocket, SOL_SOCKET, SO_RCVBUF, (char *)&optval, &optval_size);
    if (optval != SO_RCVBUFF_TARGET_SIZE)
    {
        sprintf(str, "Initialize_ListenForReplies(), ReceiveBuffer size = %d", optval);
        LogMessage(VL_Error, str);
    }

    // TODO: OSX is limiting RCVBUF size to 0x42080??

	int status = pthread_create( &EVaListenThread_ID, NULL, EVaListenThread_Func, NULL );
	if (status != 0) {
        sprintf(str,"Initialize_ListenForReplies(), pthread_create error starting EVaListenThread thread");
        LogMessage(VL_Error, str);
    }

    return OK;
}





//===================================================================
//-------------------------------------------------------------------

LOCAL int Initialize_ListenForFramesOfData()
{
    int status = pthread_create( &ReadDataThread_ID, NULL, ReadDataThread_Func, NULL );
	if (status != 0) {
        char str[256];
        sprintf(str,"Initialize_ListenForFramesOfData(), pthread_create error starting ReadDataThread thread");
        LogMessage(VL_Error, str);
    }

    return OK;
}

//==================================================================

/**   This function defines the connection routes to talk to EVaRT.
 *
 *    Machines can have more than one ethernet interface.  This function
 *    is used to either set the ethernet interface to use, or to let
 *    the SDK auto-select the local interface, and/or the EVaRT host.
 *    This function should only be called once at startup.
 *
 *  \param szMyNicCardAddress - "a.b.c.d" or HostName.  "" and NULL mean AutoSelect
 *
 *  \param szEVaNicCardAddress - "a.b.c.d" or HostName.  "" and NULL mean AutoSelect
 *
 *  \return maReturnCode - RC_Okay, RC_ApiError, RC_NetworkError, RC_GeneralError
*/
int  EVaRT2_Initialize(char* szMyNicCardAddress, char* szEVaNicCardAddress)
{
    int retval;
    char str[256];
    char str2[256];
    in_addr MyAddresses[10];
    int nAddresses; // unsigned long MyAddresses[10];


	// Initialization only happens once.
    if (bInitialized)
    {
        LogMessage(VL_Warning, "Already Initialized");
        return RC_GeneralError;
    }

    nAddresses = EVaRT2_GetAllOfMyAddresses((unsigned long *)MyAddresses, 10);
    if (nAddresses < 0)
    {
        LogMessage(VL_Error, "Geez: Unable to find my own machine");
        return RC_NetworkError;
    }
    else
    if (nAddresses == 0)
    {
        LogMessage(VL_Error, "This machine has no ethernet interfaces");
        return RC_NetworkError;
    }

    if (szMyNicCardAddress == NULL || szMyNicCardAddress[0] == 0)
    {
        if (nAddresses > 1)
        {
            LogMessage(VL_Warning, "The local machine has more than one ethernet interface.  Using the first one found.");
        }
        MyNicCardAddress = MyAddresses[0];

        strcpy(str, "Initializing using my default ethernet address: ");
    }
    else
    {
        retval = ConvertToIPAddress(szMyNicCardAddress, &MyNicCardAddress);
        if (retval != OK)
        {
            sprintf(str, "Unable to find MyNicCardAddress \"%s\"", szMyNicCardAddress);
            LogMessage(VL_Error, str);
            EVaRT2_Exit();
            return RC_NetworkError;
        }

        strcpy(str, "Initializing using my address: ");
    }

    sprintf( str2, "%s", inet_ntoa(MyNicCardAddress) );

    strcat(str, str2);
    LogMessage(VL_Info, str);

    if (ConvertToIPAddress(szEVaNicCardAddress, &EVaNicCardAddress) != OK)
    {
        sprintf(str, "Unable to convert \"%s\" to IP Address for EVaRT", szEVaNicCardAddress);
        LogMessage(VL_Error, str);
        return RC_NetworkError;
    }
	
    memset(&EVaAddr, 0, sizeof(EVaAddr));
    EVaAddr.sin_family = AF_INET;        // host byte order
    EVaAddr.sin_port = htons(wEVaPort);  // short, network byte order
    EVaAddr.sin_addr = EVaNicCardAddress;

    memset(&HostInfo, 0, sizeof(sHostInfo));
    memcpy(HostInfo.HostMachineAddress, &EVaNicCardAddress, 4);

    memset(&Polled_FrameOfData, 0, sizeof(sFrameOfData));
    memset(&LatestFrameOfData, 0, sizeof(sFrameOfData));
	
	// Get the semaphore technique initialized (CL)
    if (sem_init(&EH_CommandConfirmed, 0, 0) != 0)
    {
        sprintf(str, "Unable to initialize semaphore: ");
    }

    // this bit is to correctly init the multicast address
	struct hostent *h=gethostbyname( MULTICAST_ADDRESS_STR );
	if (h == NULL) {
		sprintf(str, "Unable to find Multicast address \"%s\"", MULTICAST_ADDRESS_STR);
        LogMessage(VL_Error, str);
        EVaRT2_Exit();
        return RC_NetworkError;
	}
    memcpy( &MultiCastAddress, h->h_addr_list[0],h->h_length );
    
    /* check given address is multicast */
	if(!IN_MULTICAST(ntohl(MultiCastAddress.s_addr))) {
		sprintf( str, "given address '%s' is not multicast\n", inet_ntoa(MultiCastAddress) );
		LogMessage(VL_Error, str);
		return RC_NetworkError;
	}
	
    Initialize_ListenForReplies();
	usleep( 10000 ); // defined in SdkSupport.h as usleep()
	
    Initialize_ListenForFramesOfData();
    usleep( 10000 ); // Give the ListenThread time to be ready for an answer to the startup packet

	// Let the world know we are here.
    PacketOut.iCommand = SWAP_SHORT( PKT2_HELLO_WORLD );
    PacketOut.nBytes = sizeof(sMe);
    strcpy(PacketOut.Data.Me.szName, "ClientTest");
    memcpy(PacketOut.Data.Me.Version, MyVersionNumber, 4);

    // Broadcast(&PacketOut);
    Broadcast(CommandSocket, wEVaPort, (char *)&PacketOut, PacketOut.nBytes + 4);

    usleep( 10000 ); // sleep for 10 milliseconds

    bInitialized = TRUE;

    return RC_Okay;
}


//==================================================================
/**   The user supplied function will be called whenever a frame of data arrives.
 *
 *    The ethernet servicing is done via a thread created
 *    when the connection to EVaRT is made.  This function is
 *    called from that thread.  Some tasks are not sharable
 *    directly across threads.  Window redrawing, for example,
 *    should be done via events or messages.
 *
 *  \param MyFunction - This user supply callback function handles the streaming data
 *
 *  \return maReturnCode - RC_Okay
 *
 *    Notes: The data parameter points to "hot" data. That frame of data
 *           will be overwritten with the next call to the callback function.
*/
int EVaRT2_SetDataHandlerFunc(void (*MyFunction)(sFrameOfData *FrameOfData))
{
    CB_DataHandler = MyFunction;
    return RC_Okay;
}


//==================================================================
/**   The user supplied function handles text messages posted from within the SDK.
 *
 *    Logging messages is done as a utility to help code and/or run using the SDK.
 *    Various messages get posted for help with error conditions or events that happen.
 *    Each message has a Log-Level assigned to it so the user can.
 *  \sa EVaRT2_SetVerbosityLevel
 *
 *
 *  \param  MyFunction - This user defined function handles messages from the SDK.
 *
 *  \return maReturnCode - RC_Okay
*/
int EVaRT2_SetErrorMsgHandlerFunc(void (*MyFunction)(int iLogLevel, char *szLogMessage))
{
    CB_ErrorMsgHandler = MyFunction;
    return RC_Okay;
}


//==================================================================
/**   This function stops all activity of the SDK.
 *
 *    This function should be called once before exiting.
*/
int EVaRT2_Exit()
{
    if (!bInitialized)
    {
        return -1;
    }

    // TODO: this looks bogus for Mac OS X, since ReadDataThread_Handle will
    // never be set... need an alternative
    if (ReadDataThread_Handle != NULL)
    {
        // should phtread_kill( ReadDataThread_Handle, 0 )
        ReadDataThread_Handle = NULL;
    }


    if (EVaListenThread_Handle != NULL)
    {
        // should pthread_kill( EVaListenThread_Handle )
        EVaListenThread_Handle = NULL;
    }


    if (CommandSocket != -1)
    {
        //closesocket(CommandSocket);
        CommandSocket = -1;
    }

    if (MultiCastReaderSocket != -1)
    {
        //closesocket(MultiCastReaderSocket);
        MultiCastReaderSocket = -1;
    }

    bInitialized = FALSE;

    return 0;
}



//==================================================================
/**   This function queries EVaRT for its set of tracking objects.
 *
 *  \return sBodyDefs* - This is a pointer to the internal storage of
 *                       the results of the latest call to this function.
 *
 *  \sa EVaRT2_FreeBodyDefs
*/
sBodyDefs* EVaRT2_GetBodyDefs()
{
    int nTries = 10000; int count = 3;
	char str[256];

    PacketOut.iCommand = SWAP_SHORT( PKT2_REQUEST_BODYDEFS );
    PacketOut.nBytes = 0;

	while(count--)
	{
		// In Linux, POSIX semaphores are of the auto-reset type
		// ResetEvent(EH_CommandConfirmed);

	    SendToEVa(&PacketOut);

		// Sleep for a long enough time to expect a response
		// Currently set to 100 ms. (CL)
	    while (nTries--)
    	{
        
			int retCode = sem_trywait(&EH_CommandConfirmed);
			if (!retCode)  {

	       		/* Event is signaled */
				return pNewBodyDefs;

			} else {

	   			/* check whether somebody else has the semaphore locked */
   				if (errno == EAGAIN) {
        	   		usleep( 10 ); /* sleep for 10us */
					LogMessage(VL_Debug, "Somebody else has the semaphore locked");
   				} else {
					sprintf(str, "Error in semaphore timeout in GetBodyDefs (No. %d)",errno);
				    LogMessage(VL_Debug, str);
				}
	
			}
	
	    }
	
	}

    LogMessage(VL_Error, "No response from EVaRT");
    return NULL;
}


//==================================================================
/**   This function frees the memory allocated by EVaRT2_GetBodyDefs
 *
 *  The data within the structure is freed and also the structure itself.

 * \param pBodyDefs - The item to free.
 *
 * \return RC_Okay
*/
int EVaRT2_FreeBodyDefs(sBodyDefs* pBodyDefs)
{
    int nBodies = pBodyDefs->nBodyDefs;
    int iBody;

    for (iBody=0 ; iBody<nBodies ; iBody++)
    {
        sBodyDef *pBody = &pBodyDefs->BodyDefs[iBody];

     // Free each array of pointers to the names
        if (pBody->szMarkerNames            != NULL) free(pBody->szMarkerNames);
        if (pBody->Hierarchy.szSegmentNames != NULL) free(pBody->Hierarchy.szSegmentNames);
        if (pBody->Hierarchy.iParents       != NULL) free(pBody->Hierarchy.iParents);
        if (pBody->szDofNames               != NULL) free(pBody->szDofNames);
    }

    if (pBodyDefs->szAnalogChannelNames != NULL) free(pBodyDefs->szAnalogChannelNames);

 // Free the big space that contains all the names
    if (pBodyDefs->AllocatedSpace != NULL) free(pBodyDefs->AllocatedSpace);
    memset(pBodyDefs, 0, sizeof(sBodyDef)); // not needed anymore
    free(pBodyDefs);

    return RC_Okay;
}


LOCAL int Unpack_BodyDef(char **pptr, sBodyDef *BodyDef)
{
    int nMarkers;
    int nSegments;
    int nDofs;
    int iMarker;
    int iSegment;
    int iDof;
    char *ptr = *pptr;

 // The main name

    BodyDef->szName = ptr;
    ptr += strlen(ptr) + 1;


 // Markers

    memcpy(&nMarkers, ptr, 4);
	nMarkers = SWAP_LONG( nMarkers );
    BodyDef->nMarkers = nMarkers;
    ptr += 4;
	
    BodyDef->szMarkerNames = (char **)malloc(nMarkers*4);

    for (iMarker=0 ; iMarker<nMarkers ; iMarker++)
    {
        BodyDef->szMarkerNames[iMarker] = ptr;
        ptr += strlen(ptr) + 1;
    }


 // Segments

    memcpy(&nSegments, ptr, 4);
	nSegments = SWAP_LONG( nSegments );
    BodyDef->Hierarchy.nSegments = nSegments;
    ptr += 4;

    BodyDef->Hierarchy.szSegmentNames = (char **)malloc(nSegments*4);
    BodyDef->Hierarchy.iParents = (int *)malloc(nSegments*sizeof(int));

    for (iSegment=0 ; iSegment<nSegments ; iSegment++)
    {
        BodyDef->Hierarchy.szSegmentNames[iSegment] = ptr;
        ptr += strlen(ptr) + 1;

        memcpy(&BodyDef->Hierarchy.iParents[iSegment], ptr, 4);
		BodyDef->Hierarchy.iParents[iSegment] = SWAP_LONG( BodyDef->Hierarchy.iParents[iSegment] );
        ptr += 4;
    }


 // Dofs

    memcpy(&nDofs, ptr, 4);
	nDofs = SWAP_LONG( nDofs );
    BodyDef->nDofs = nDofs;
    ptr += 4;

    BodyDef->szDofNames = (char **)malloc(nDofs*4);

    for (iDof=0 ; iDof<nDofs ; iDof++)
    {
        BodyDef->szDofNames[iDof] = ptr;
        ptr += strlen(ptr) + 1;
    }


    *pptr = ptr;
    return 0;
}


LOCAL int Unpack_AnalogDefs(char** pptr, sBodyDefs* pBodyDefs)
{
    char*  ptr = *pptr;
    int    iChannel;
    int    nChannels;
    int    nForcePlates;

    memcpy(&nChannels, ptr, 4);
	nChannels = SWAP_LONG( nChannels );
    ptr += 4;

    pBodyDefs->nAnalogChannels = nChannels;
    pBodyDefs->szAnalogChannelNames = (char **)malloc(nChannels*4);

    for (iChannel=0 ; iChannel<nChannels ; iChannel++)
    {
        pBodyDefs->szAnalogChannelNames[iChannel] = ptr;
        ptr += strlen(ptr) + 1;
    }

    memcpy(&nForcePlates, ptr, 4);
	nForcePlates = SWAP_LONG( nForcePlates );
    ptr += 4;
    pBodyDefs->nForcePlates = nForcePlates;

    *pptr = ptr;
    return 0;
}


LOCAL sBodyDefs* Unpack_BodyDefs(char *Data, int nBytes)
{
    char *ptr = Data;
    char *MyBuffer;
    int  iBody;
    int  nBodies;
    sBodyDefs *pBodyDefs;

    pBodyDefs = (sBodyDefs *)malloc(sizeof(sBodyDefs));
    if (pBodyDefs == NULL)
    {
        return NULL;
    }

    memset(pBodyDefs, 0, sizeof(sBodyDefs));

    MyBuffer = (char *)malloc(nBytes);
    if (MyBuffer == NULL)
    {
        free(pBodyDefs);
        return NULL;
    }
    pBodyDefs->AllocatedSpace = MyBuffer;


    memcpy(MyBuffer, Data, nBytes);
    ptr = MyBuffer;

    memcpy(&nBodies, ptr, 4);
	nBodies = SWAP_LONG( nBodies );
    pBodyDefs->nBodyDefs = nBodies;
    ptr += 4;

    for (iBody=0 ; iBody<nBodies ; iBody++)
    {
        Unpack_BodyDef(&ptr, &pBodyDefs->BodyDefs[iBody]);
    }

    Unpack_AnalogDefs(&ptr, pBodyDefs);

    return pBodyDefs;
}


LOCAL int Unpack_BodyData(char **pptr, sBodyData *pBody)
{
    char *ptr = *pptr;
    int nBytes = 0;
    int nTotalBytes = 0;
    int nMarkers;
    int nSegments;
    int nDofs;
	int i;

 // Name of the object

    strcpy(pBody->szName, ptr);
    nBytes = strlen(pBody->szName) + 1;
    ptr += nBytes;
    nTotalBytes += nBytes;

 // The Markers

    memcpy(&nMarkers, ptr, 4);
	nMarkers = SWAP_LONG( nMarkers );
    ptr += 4;
    nTotalBytes += 4;

    nBytes = nMarkers * sizeof(tMarkerData);

    if (nMarkers != pBody->nMarkers)
    {
        pBody->nMarkers = nMarkers;
        pBody->Markers = (tMarkerData*)realloc(pBody->Markers, nBytes);
		if (pBody->Markers == NULL)
			perror( "Unpack_BodyData, realloc for markers" );
    }

    memcpy(pBody->Markers, ptr, nBytes);
    ptr += nBytes;
    nTotalBytes += nBytes;
	
	// fix byte order of named markers
	for (i=0 ; i<pBody->nMarkers ; i++) 
	{
		pBody->Markers[i][0] = SWAP_FLOAT( pBody->Markers[i][0] );
		pBody->Markers[i][1] = SWAP_FLOAT( pBody->Markers[i][1] );
		pBody->Markers[i][2] = SWAP_FLOAT( pBody->Markers[i][2] );
	}


 // The Segments

    memcpy(&nSegments, ptr, 4);
	nSegments = SWAP_LONG( nSegments );
    ptr += 4;
    nTotalBytes += 4;

    nBytes = nSegments * sizeof(tSegmentData);

    if (nSegments != pBody->nSegments)
    {
        pBody->nSegments = nSegments;
        pBody->Segments = (tSegmentData*)realloc(pBody->Segments, nBytes);
		if (pBody->Segments == NULL)
			perror( "Unpack_BodyData, realloc for segments" );
    }

    memcpy(pBody->Segments, ptr, nBytes);
    ptr += nBytes;
    nTotalBytes += nBytes;
	
	// fix byte order of segments
	for (i=0 ; i<pBody->nSegments ; i++) 
	{
		pBody->Segments[i][0] = SWAP_DOUBLE( pBody->Segments[i][0] );
		pBody->Segments[i][1] = SWAP_DOUBLE( pBody->Segments[i][1] );
		pBody->Segments[i][2] = SWAP_DOUBLE( pBody->Segments[i][2] );
		pBody->Segments[i][3] = SWAP_DOUBLE( pBody->Segments[i][3] );
		pBody->Segments[i][4] = SWAP_DOUBLE( pBody->Segments[i][4] );
		pBody->Segments[i][5] = SWAP_DOUBLE( pBody->Segments[i][5] );
		pBody->Segments[i][6] = SWAP_DOUBLE( pBody->Segments[i][6] );
	}


 // The Dofs

    memcpy(&nDofs, ptr, 4);
	nDofs = SWAP_LONG( nDofs );
    ptr += 4;
    nTotalBytes += 4;

    nBytes = nDofs * sizeof(tDofData);

    if (nDofs != pBody->nDofs)
    {
        pBody->nDofs = nDofs;
        pBody->Dofs = (tDofData*)realloc(pBody->Dofs, nBytes);
		if (pBody->Dofs == NULL)
			perror( "Unpack_BodyData, realloc for Dofs" );
    }

    memcpy(pBody->Dofs, ptr, nBytes);
    ptr += nBytes;
    nTotalBytes += nBytes;
	
	// fix byte order of nDofs
	for (i = 0; i < pBody->nDofs; i++) 
	{
		pBody->Dofs[i] = SWAP_DOUBLE( pBody->Dofs[i] );
	}

 // That's all folks

    *pptr = ptr;
    return nTotalBytes;
}


LOCAL int Unpack_AnalogData(char** pptr, sAnalogData* pUnpacked)
{
    char *ptr = *pptr;
    int nBytes;
    int  nTotalBytes = 0;
    int nSamples;
    int nChannels;
    int nForceSamples;
    int nForcePlates;

 // Raw analog samples

    memcpy(&nChannels, ptr, 4);
	nChannels = SWAP_LONG( nChannels );
    ptr += 4;
    nTotalBytes += 4;

    memcpy(&nSamples, ptr, 4);
	nSamples = SWAP_LONG( nSamples );
    ptr += 4;
    nTotalBytes += 4;

    if (nSamples != pUnpacked->nAnalogSamples
     || nChannels != pUnpacked->nAnalogChannels)
    {
        pUnpacked->nAnalogSamples = nSamples;
        pUnpacked->nAnalogChannels = nChannels;
        pUnpacked->AnalogSamples = (short*)realloc(pUnpacked->AnalogSamples, nSamples*nChannels*sizeof(short));
		if (pUnpacked->AnalogSamples == NULL)
			perror( "Unpack_AnalogData, AnalogSamples realloc failed" );
    }

    nBytes = nSamples*nChannels*sizeof(short);
    memcpy(pUnpacked->AnalogSamples, ptr, nBytes);
    ptr += nBytes;
    nTotalBytes += nBytes;
	
	// fix byte order of AnalogData
	short *pSample = pUnpacked->AnalogSamples;
	int iSample;
	int iChannel;
	for (iSample=0 ; iSample<nSamples ; iSample++)
	{
		for (iChannel=0 ; iChannel<nChannels ; iChannel++)
		{
			*pSample = SWAP_SHORT( *pSample );
			pSample++;
		}
	}

 // Force data

    memcpy(&nForcePlates, ptr, 4);
	nForcePlates = SWAP_LONG( nForcePlates );
    ptr += 4;
    nTotalBytes += 4;

    memcpy(&nForceSamples, ptr, 4);
	nForceSamples = SWAP_LONG( nForceSamples );
    ptr += 4;
    nTotalBytes += 4;

    if (nForceSamples != pUnpacked->nForceSamples
     || nForcePlates != pUnpacked->nForcePlates)
    {
        pUnpacked->nForceSamples = nForceSamples;
        pUnpacked->nForcePlates = nForcePlates;
        pUnpacked->Forces = (tForceData*)realloc(
            pUnpacked->Forces,
            nForceSamples*nForcePlates*sizeof(tForceData));
		if (pUnpacked->Forces == NULL)
			perror( "Unpack_AnalogData, Forces realloc failed" );
    }

    nBytes = nForceSamples*nForcePlates*sizeof(tForceData);
    memcpy(pUnpacked->Forces, ptr, nBytes);
    ptr += nBytes;
    nTotalBytes += nBytes;
	
	// fix byteorder of Forces
	int iPlate;
	tForceData *Force = pUnpacked->Forces;
	for (iSample=0 ; iSample<nForceSamples ; iSample++)
    {
        for (iPlate=0 ; iPlate<nForcePlates ; iPlate++)
        {
			(*Force)[0] = SWAP_FLOAT( (*Force)[0] );
			(*Force)[1] = SWAP_FLOAT( (*Force)[1] );
			(*Force)[2] = SWAP_FLOAT( (*Force)[2] );
			(*Force)[3] = SWAP_FLOAT( (*Force)[3] );
			(*Force)[4] = SWAP_FLOAT( (*Force)[4] );
			(*Force)[5] = SWAP_FLOAT( (*Force)[5] );
			(*Force)[6] = SWAP_FLOAT( (*Force)[6] );
			
            Force++;
        }
    }

    return nTotalBytes;
}


LOCAL int Unpack_UnnamedMarkers(char **pptr, sFrameOfData *Frame)
{
    char *ptr = *pptr;
    int nBytes = 0;
    int  nTotalBytes = 0;
    int nMarkers;
	int i;

    memcpy(&nMarkers, ptr, 4);
	nMarkers = SWAP_LONG( nMarkers );
    ptr += 4;
    nTotalBytes += 4;

    nBytes = nMarkers*sizeof(tMarkerData);

    if (nMarkers != Frame->nUnidentifiedMarkers)
    {
        Frame->nUnidentifiedMarkers = nMarkers;
        Frame->UnidentifiedMarkers = (tMarkerData*)realloc(Frame->UnidentifiedMarkers, nBytes);
		if (Frame->UnidentifiedMarkers == NULL)
			perror( "Unpack_UnnamedMarkers, UnidentifiedMarkers realloc failed" );
    }

    memcpy(Frame->UnidentifiedMarkers, ptr, nBytes);
    ptr += nBytes;
    nTotalBytes += nBytes;
	
	// fix byte order of unidentified markers
	for (i=0 ; i<nMarkers ; i++) 
	{
		Frame->UnidentifiedMarkers[i][0] = SWAP_FLOAT( Frame->UnidentifiedMarkers[i][0] );
		Frame->UnidentifiedMarkers[i][1] = SWAP_FLOAT( Frame->UnidentifiedMarkers[i][1] );
		Frame->UnidentifiedMarkers[i][2] = SWAP_FLOAT( Frame->UnidentifiedMarkers[i][2] );
	}

    *pptr = ptr;
    return nTotalBytes;
}


LOCAL int Unpack_FrameOfData(char *Data, int nTotalBytes, sFrameOfData *Frame)
{
    char *ptr = Data;
    int nBytes = 0;
    int iBody;
    int nBodies;

    if (Data == NULL || Frame == NULL)
    {
        return RC_ApiError;
    }

    memcpy(&Frame->iFrame, ptr, 4); ptr += 4; nBytes += 4;

    memcpy(&nBodies, ptr, 4); ptr += 4; nBytes += 4;
	
	Frame->iFrame = SWAP_LONG( Frame->iFrame );
	nBodies = SWAP_LONG( nBodies );

    if (nBodies < 0  ||  nBodies > MAX_N_BODIES)
    {
        LogMessage(VL_Error, "nBodies parameter is out of range");
        return RC_GeneralError;
    }

    Frame->nBodies = nBodies;

    for (iBody=0 ; iBody<nBodies ; iBody++)
    {
        nBytes += Unpack_BodyData(&ptr, &Frame->BodyData[iBody]);
    }

 // Unnamed markers

    Unpack_UnnamedMarkers(&ptr, Frame);


 // Analog

    nBytes += Unpack_AnalogData(&ptr, &Frame->AnalogData);

    return nBytes;
}


//==================================================================
/**   This function returns a 4-byte version number.
 *
 * \param Version - An array of four bytes: ModuleID, Major, Minor, Bugfix
 *
 * \return RC_Okay
*/
int EVaRT2_GetSdkVersion(unsigned char Version[4])
{
    memcpy(Version, MyVersionNumber, 4);
    return RC_Okay;
}


//==================================================================
/**   This function sends commands to EVaRT and returns a response.
 *
 *    This function is an extendable interface between the Client programs
 *    and the Host (EVaRT) program.  The commands are sent as readable text strings.
 *    The response is returned unaltered.
 *
 * \param szCommand - The request to send the EVaRT
 * \param Response - The reply
 * \param pnBytes - The number of bytes in the response
 *
 \verbatim
Example:
    void *pResponse=NULL;
    EVaRT2_Request("GetFrameRate", &pResponse, sizeof(void*));
    fFrameRate = *(float*)pResponse;
\endverbatim 
 *
 * \return RC_Okay, RC_TimeOut, RC_NotRecognized, RC_GeneralError
*/
int EVaRT2_Request(char* szCommand, void** Response, int *pnBytes)
{
    char str[256] = "Requesting: ";
    int nTries=2000; int count=3;

    *pnBytes = 0;

    strcat(str, szCommand);
    LogMessage(VL_Debug, str);

    PacketOut.iCommand = SWAP_SHORT( PKT2_GENERAL_REQUEST );
    PacketOut.nBytes = strlen(szCommand) + 1;
    strcpy(PacketOut.Data.String, szCommand);


	while(count--)
	{
		SendToEVa(&PacketOut);

    	while (nTries--)
    	{
        
			int retCode = sem_trywait(&EH_CommandConfirmed);
			if (!retCode)  {

       			/* Event is signaled */
       			if (SWAP_SHORT(PacketIn.iCommand) == PKT2_GENERAL_REPLY)
            	{
	                *Response = PacketIn.Data.cData;
    	            *pnBytes = PacketIn.nBytes;
        	        return RC_Okay;
	            }
    	        else
        	    if (SWAP_SHORT(PacketIn.iCommand) == PKT2_UNRECOGNIZED_REQUEST)
            	{
					LogMessage(VL_Warning, "EVaRT2_Request, Unrecognized Request" );
    	            *Response = NULL;
        	        return RC_Unrecognized;
	            }
    	        else
        	    {
					LogMessage(VL_Warning, "EVaRT2_Request, GeneralError" );
                	return RC_GeneralError;
	            }   

			} else {

				/* check whether somebody else has the semaphore locked */
   				if (errno == EAGAIN) {
           			usleep(10); /* sleep for 10us */
					LogMessage(VL_Debug, "Somebody else has the semaphore locked");
	   			} else {
					sprintf(str, "Error in semaphore timeout after Request (No. %d)",errno);
				    LogMessage(VL_Debug, str);
				}

			}

		}

	}

	LogMessage(VL_Warning, "EVaRT2_Request, Request Timeout" );
    *Response = NULL;
    return RC_TimeOut;
}


//==================================================================
/** This function sets the filter level of the LogMessages.
 *
 *  The default verbosity level is VL_Warning.
 *
 * \param iLevel - one of the maVerbosityLevel enum values.
 *
 * \return RC_Okay
*/
int EVaRT2_SetVerbosityLevel(int iLevel)
{
    User_VerbosityLevel = iLevel;
    return RC_Okay;
}


//==================================================================
/** This function gets information about the connection to EVaRT
 *
 *  This function returns IP-Address information and EVaRT version information.
 *  The version info can be used to handle incompatible changes in either our code
 *  or your code.
 *
 * \param pHostInfo - Structure containing connection information
 *
 * \return RC_Okay, RC_NetworkError
*/
int EVaRT2_GetHostInfo(sHostInfo *pHostInfo)
{
	char str[256];
    
    sprintf(str, "HostInfo: %s Version %d.%d.%d at %d.%d.%d.%d (%s)",
            HostInfo.szHostProgramName,
            HostInfo.HostProgramVersion[1],
            HostInfo.HostProgramVersion[2],
            HostInfo.HostProgramVersion[3],
            HostInfo.HostMachineAddress[0],
            HostInfo.HostMachineAddress[1],
            HostInfo.HostMachineAddress[2],
            HostInfo.HostMachineAddress[3],
            HostInfo.szHostMachineName);
    LogMessage( VL_Debug, str );
	
    if (HostInfo.HostMachineAddress[0] == 0)
    {
		LogMessage(VL_Debug, "GetHostInfo, HostMachineAddress is 0" );
        return RC_NetworkError;
    }

    memcpy(pHostInfo, &HostInfo, sizeof(sHostInfo));
    return RC_Okay;
}


//==================================================================
/** This function polls EVaRT for the current frame
 *
 *  The SDK user has the streaming data available via the callback function.
 *  In addition, this function is available to get a frame directly.
 *
 *  Note: EVaRT considers the current frame to be the latest LiveMode frame completed or,
 *        if not in LiveMode, the current frame is the one that is displayed on the screen.
 *
 * \return sFrameOfData
*/
sFrameOfData* EVaRT2_GetCurrentFrame()
{
    PacketOut.iCommand = SWAP_SHORT( PKT2_REQUEST_FRAME );
    PacketOut.nBytes = 0;

	// Sleep for a long enough time to expect a response
	// Currently set to 20 ms.

    int bytesSent = SendToEVa(&PacketOut);
	char str[256];
	sprintf( str, "EVaRT2_GetCurrentFrame(), SendToEVa sent %d bytes", bytesSent );
	LogMessage( VL_Debug, str );

	int nTries = 2000;
	while (nTries--)
    {
		int retCode = sem_trywait(&EH_CommandConfirmed);
		if (!retCode)  {

			/* Event is signaled */
       		if (SWAP_SHORT(PacketIn.iCommand) == PKT2_FRAME_OF_DATA)
            {

            	LogMessage(VL_Debug, "FRAME_OF_DATA message" );
				return &Polled_FrameOfData; 

            } else if (SWAP_SHORT(PacketIn.iCommand) == PKT2_GENERAL_REPLY) {

            	LogMessage(VL_Debug, "GENERAL_REPLY message" );

			}

		} else {

			/* check whether somebody else has the semaphore locked */
   			if (errno == EAGAIN) {
           		usleep(10); /* sleep for 10us */
				LogMessage(VL_Debug, "Somebody else has the semaphore locked");
   			} else {
				sprintf(str, "Error in semaphore timeout in GetCurrentFrame (No. %d)",errno);
			    LogMessage(VL_Debug, str);
			}
   			
		}
	}

    return NULL;
}


//==================================================================
/** This function copies a frame of data.
 *
 *  The Destination frame should start initialized to all zeros.  The CopyFrame
 *  and FreeFrame functions will handle the memory allocations necessary to fill
 *  out the data.
 *
 * \param pSrc - The frame to copy FROM.
 * \param pDst - The frame to copy TO
 *
 * \return RC_Okay, RC_MemoryError
*/
int EVaRT2_CopyFrame(const sFrameOfData* pSrc, sFrameOfData* pDst)
{
    int iBody;
    int nBodies = pSrc->nBodies;
    const sBodyData* SrcBody;
    sBodyData* DstBody;

    int n;
    void *ptr;
    int size;

    pDst->iFrame = pSrc->iFrame;

    pDst->nBodies = nBodies;

    for (iBody=0 ; iBody<nBodies ; iBody++)
    {
		//printf( "   body %d\n", iBody );
        SrcBody = &pSrc->BodyData[iBody];
        DstBody = &pDst->BodyData[iBody];

     // Copy Markers

        n = SrcBody->nMarkers;
        size = n * sizeof(tMarkerData);

        if (DstBody->nMarkers != n)
        {
            ptr = realloc(DstBody->Markers, size);
            if (size > 0 && ptr == NULL)
            {
                EVaRT2_FreeFrame(pDst);
                return RC_MemoryError;
            }
            DstBody->nMarkers = n;
            DstBody->Markers = (tMarkerData*)ptr;
        }

        memcpy(DstBody->Markers, SrcBody->Markers, size);


     // Copy Segments

        n = SrcBody->nSegments;
        size = n * sizeof(tSegmentData);

        if (DstBody->nSegments != n)
        {
            ptr = realloc(DstBody->Segments, size);
            if (size > 0 && ptr == NULL)
            {
                EVaRT2_FreeFrame(pDst);
                return RC_MemoryError;
            }
            DstBody->nSegments = n;
            DstBody->Segments = (tSegmentData*)ptr;
        }

        memcpy(DstBody->Segments, SrcBody->Segments, size);


     // Copy DOFs

        n = SrcBody->nDofs;
        size = n * sizeof(tDofData);

        if (DstBody->nDofs != n)
        {
            ptr = realloc(DstBody->Dofs, size);
            if (size > 0 && ptr == NULL)
            {
                EVaRT2_FreeFrame(pDst);
                return RC_MemoryError;
            }
            DstBody->nDofs = n;
            DstBody->Dofs = (tDofData*)ptr;
        }

        memcpy(DstBody->Dofs, SrcBody->Dofs, size);
    }


 // Copy Unidentified Markers

    n = pSrc->nUnidentifiedMarkers;
    size = n * sizeof(tMarkerData);

    if (pDst->nUnidentifiedMarkers != n)
    {
        ptr = realloc(pDst->UnidentifiedMarkers, size);
        if (size > 0 && ptr == NULL)
        {
            EVaRT2_FreeFrame(pDst);
            return RC_MemoryError;
        }
        pDst->nUnidentifiedMarkers = n;
        pDst->UnidentifiedMarkers = (tMarkerData*)ptr;
    }

    memcpy(pDst->UnidentifiedMarkers, pSrc->UnidentifiedMarkers, size);


 // Copy Analog

    const sAnalogData* SrcAnalog = &pSrc->AnalogData;
    sAnalogData* DstAnalog = &pDst->AnalogData;

 // Analog Channels

    int nChannels = SrcAnalog->nAnalogChannels;
    int nSamples = SrcAnalog->nAnalogSamples;

    size = nChannels * nSamples * sizeof(short);

    if (DstAnalog->nAnalogChannels != nChannels
     || DstAnalog->nAnalogSamples != nSamples)
    {
        ptr = realloc(DstAnalog->AnalogSamples, size);
        if (size > 0 && ptr == NULL)
        {
            EVaRT2_FreeFrame(pDst);
            return RC_MemoryError;
        }
        DstAnalog->nAnalogChannels = nChannels;
        DstAnalog->nAnalogSamples = nSamples;
        DstAnalog->AnalogSamples = (short*)ptr;
    }

    memcpy(DstAnalog->AnalogSamples, SrcAnalog->AnalogSamples, size);


 // Forces Data

    int nForcePlates = SrcAnalog->nForcePlates;
    int nForceSamples = SrcAnalog->nForceSamples;
 
    size = nForcePlates * nForceSamples * sizeof(tForceData);
 
    if (DstAnalog->nForcePlates != nForcePlates
     || DstAnalog->nForceSamples != nForceSamples)
    {
        ptr = realloc(DstAnalog->Forces, size);
        if (size > 0 && ptr == NULL)
        {
            EVaRT2_FreeFrame(pDst);
            return RC_MemoryError;
        }
        DstAnalog->nForcePlates = nForcePlates;
        DstAnalog->nForceSamples = nForceSamples;
        DstAnalog->Forces = (tForceData*)ptr;
    }

    memcpy(DstAnalog->Forces, SrcAnalog->Forces, size);

    return RC_Okay;
}


//==================================================================
/** This function frees memory within the structure.
 *
 *  The sFrameOfData structure includes pointers to various pieces of data.
 *  That data is dynamically allocated or reallocated to be consistent with
 *  the data that has arrived from EVaRT.  To properly use the sFrameOfData
 *  structure, you should use the utility functions supplied.  It is possible
 *  to reuse sFrameOfData variables without ever freeing them.  The SDK will
 *  reallocate the components for you.
 *
 * \param pFrame - The frame of data to free.
 *
 * \return RC_Okay
*/
int EVaRT2_FreeFrame(sFrameOfData* pFrame)
{
    int iBody;

    for (iBody=0 ; iBody<MAX_N_BODIES ; iBody++)
    {
        sBodyData* Body = &pFrame->BodyData[iBody];

        if (Body->Markers != NULL) free(Body->Markers);
        if (Body->Segments != NULL) free(Body->Segments);
        if (Body->Dofs != NULL) free(Body->Dofs);
    }
    if (pFrame->UnidentifiedMarkers != NULL) free(pFrame->UnidentifiedMarkers);

    if (pFrame->AnalogData.AnalogSamples != NULL) free(pFrame->AnalogData.AnalogSamples);
    if (pFrame->AnalogData.Forces != NULL) free(pFrame->AnalogData.Forces);

    memset(pFrame, 0, sizeof(sFrameOfData));

    return RC_Okay;
}


LOCAL int SendToEVa(sPacket *Packet)
{
     // Here's my response back to the requestor

    return sendto(
        CommandSocket,
        (char *)Packet,
        4 + Packet->nBytes,
        0,
        (sockaddr *)&EVaAddr,
        sizeof(EVaAddr));
}


LOCAL int GetHostByAddr(unsigned char Address[4], char szName[])
{
    hostent* pHostEnt;
		
    //pHostEnt = gethostbyaddr((char*)Address, 4, PF_INET);
	pHostEnt = gethostbyaddr((char*)Address, 4, AF_INET);
	
    if (pHostEnt == NULL)
    {
        LogMessage(VL_Error, "Unable to get EVaHost name information");
        return RC_NetworkError;
    }
    strcpy(szName, pHostEnt->h_name);
	// strcpy(szName, "Selvik");

    return RC_Okay;
}


LOCAL THREAD_FUNC GetHostByAddrThread_Func(void* _HostInfo)
{
    sHostInfo *HostInfo = (sHostInfo *)_HostInfo;

    GetHostByAddr(HostInfo->HostMachineAddress, HostInfo->szHostMachineName);

    return 0;
}

LOCAL void GetHostName_ASYNC()
{
    int status = pthread_create( &GetHostNameThread_ID, NULL, GetHostByAddrThread_Func, (void*)&HostInfo );
	if (status != 0) {
        char str[256];
        sprintf(str,"pthread_create error starting GetHostByAddrThread_Func thread");
        LogMessage(VL_Error, str);
    }
}
