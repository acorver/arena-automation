/*=========================================================
//
// File: Socket.cpp  v200
//
// Created by Ned Phipps, Oct-2004
//
=============================================================================*/

#include <stdio.h>

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <ctype.h>
#include <netdb.h>
#include <unistd.h>

#include "SdkSupport.h"
#include "EVaRT2.h"

//int ProcessSocketError();

/*===========================================================
//
//  Socket_CreateForBroadcasting
//
//  Description: creates and initializes a broadcast socket
//
//  Parameters:
//      IP_Address:  4 byte ethernet address
//      uPort:       port number on this machine.
//
//  Returns:
//      SOCKET:  socket id, or
//               -1 if error occurred
//
//  Notes:
//
//      The socket is bound to the specified IP address
//      and the port number.
//
//      The socket can be used to send to one destination
//      or to broadcast from.
//
//------------------------------------------------------------*/
SOCKET Socket_CreateForBroadcasting(unsigned long IP_Address, unsigned short uPort)
{
    struct sockaddr_in my_addr;     // socket address information
    static unsigned long ivalue;
    SOCKET sockfd;


    // Create a socket.
    // param 1 = address family, AF_INET is Internet, incl. UDP & TCP
    // param 2 = stream or datagram, param 3 = protocol, 0 = TCP. In all examples
    // I've seen, 0 is the value used, but I'm not sure why other values aren't used,
    // such as IPPROTO_TCP   6  for tcp
    // and     IPPROTO_UDP  17  for user datagram protocol
    if ((sockfd=socket(AF_INET, SOCK_DGRAM, 0)) == INVALID_SOCKET)
    {
        //printf("\nServer socket creation failed with error %d.\n", WSAGetLastError());
		LogMessage( VL_Error, "\nServer socket creation failed with error.\n" );
        ProcessSocketError();
        return -1;
    }


 // We bind the socket to our local NIC card.

    memset(&my_addr, 0, sizeof(my_addr));
    my_addr.sin_family = AF_INET;
    my_addr.sin_port = htons(uPort);

#if 0 // Use any (or all?) of the local NIC cards.
    my_addr.sin_addr.s_addr = INADDR_ANY;
#endif

#if 0 // Siggraph used this particular address for its second ethernet card
    my_addr.sin_addr.S_un.S_un_b.s_b1 = 10;
    my_addr.sin_addr.S_un.S_un_b.s_b2 = 1;
    my_addr.sin_addr.S_un.S_un_b.s_b3 = 1;
    my_addr.sin_addr.S_un.S_un_b.s_b4 = 199;
#endif


    //my_addr.sin_addr.s_addr = htonl( IP_Address );
	my_addr.sin_addr.s_addr = htonl( INADDR_ANY );

    // When a socket is first created, it exists in a name space (address family), but
    // it has no name assigned to it. So we use the bind() function to assign a
    // local name (local address) to the unnamed socket.  Since our application
    // does not care what local address is assigned, we use the value INADDR_ANY.
    // In our application we specify a specific port number, but if we had assigned
    // a port value of 0, it would mean to let bind() choose any unused port
    // with a value between 1024 and 5000.

    if (bind(sockfd, (struct sockaddr *)&my_addr, sizeof(struct sockaddr))
              == SOCKET_ERROR)
    {
        //printf("\nServer: bind() failed with error = %d.\n", WSAGetLastError());
		printf("\nServer: bind() failed with error.\n" );
        ProcessSocketError();
        //closesocket(sockfd);
        return -1;
    }

/*
    // When a socket is created, the default is blocking mode (nonblocking mode is
    // disabled. Use ioctlsocket() to set the I/O mode to be nonblocking.
    bFlag = 1;      // a nonzero value enables nonblocking mode.
    if (ioctlsocket(sockfd, FIONBIO, (unsigned long *)&bFlag) == SOCKET_ERROR)
    {
        //printf("\nServer: ioctl(FIONBIO) failed with error = %d.\n", WSAGetLastError());
        ProcessSocketError();
        closesocket(sockfd);
        WSACleanup();
        return(-1);
    }
*/


 // Set the socket to broadcast mode.
    ivalue = 1;
    if (setsockopt(sockfd,
        SOL_SOCKET,             // protocol level
        SO_BROADCAST,           
        (char *)&ivalue,         // nonzero value enables the boolean SO_BROADCAST option
        sizeof(ivalue))
        == SOCKET_ERROR)
    {
        ProcessSocketError();
        closesocket(sockfd);
        return -1;
    }

#if 0
    char str[256];

	// Diagnostic: find out the maximum size of the socket send buffer.
    int four = 4;
	if (getsockopt(sockfd, SOL_SOCKET, SO_SNDBUF, (char *)&ivalue, &four)
			== SOCKET_ERROR)
	{
        ProcessSocketError();
        closesocket(sockfd);
		return -1;
	}
    sprintf(str, "Max Send Buffer Size = %d", ivalue);
    PopupNotice(str);

    // Diagnostic: find out the maximum size of the socket receive buffer.
	if (getsockopt(sockfd, SOL_SOCKET, SO_RCVBUF, (char *)&ivalue, &four)
			== SOCKET_ERROR)
	{
        ProcessSocketError();
        closesocket(sockfd);
		return -1;
	}
    sprintf(str, "Max Receive Buffer Size = %d", ivalue);
    PopupNotice(str);
#endif


    return sockfd;
}



int ConvertToIPAddress(char *szNameOrAddress, struct in_addr *Address)
{
    struct hostent* haddr=NULL;
//    char s[256];

    if (szNameOrAddress == NULL
     || szNameOrAddress[0] == 0)
    {
        Address->s_addr = htonl( INADDR_BROADCAST );
        return 0;
    }

    /* find Internet address of host */

	if (!isalpha(szNameOrAddress[0]))
    {
     /* Convert a.b.c.d address to a usable one */
        haddr = gethostbyname( szNameOrAddress );
        if (haddr != NULL)
        {
            Address->s_addr = inet_addr( szNameOrAddress );
            return 0;
        }
		else {
			printf("Warning, gethostbyname returned NULL (thought we had an IP address)\n");
		}

        return -1;
	}

    /* server address is a name */
    haddr = gethostbyname(szNameOrAddress);
    if (haddr == NULL)
    {
		printf("Warning, gethostbyname returned NULL (thought we had a name\n");
        return -1;
    }

    if (haddr->h_length != sizeof(in_addr))
    {
//        LOGMESSAGE("SOCKET ERROR: address sizes dont match?!");
        return -1;
    }

    memcpy(
           Address,
           haddr->h_addr_list[0],
           sizeof(in_addr));

    return 0; 
}



/***********************************************************

	Function: int Broadcast(char *Buffer, int nBytes)

	Description: broadcast the message contained in the first 
			parameter to all cameras on the network

	Parameters:
			char * Buffer	pointer to buffer containing the
							ASCII message
			int nBytes		number of bytes in the message

	Return Values: 
			numbytes if successful
			-1 if unsuccessful

*************************************************************/
int Broadcast(SOCKET sockfd, unsigned short uPort, char *Buffer, int nBytes)
{
    struct sockaddr_in their_addr; // client connector's address information
    int numbytes;

    //if (sockfd <= 0) return 0;
    if (sockfd == -1) return 0;


    their_addr.sin_family = AF_INET;      // host byte order
    their_addr.sin_port = htons(uPort);  // short, network byte order
    their_addr.sin_addr.s_addr = INADDR_BROADCAST;

#if 0
    their_addr.sin_addr.S_un.S_un_b.s_b1 = 10;
    their_addr.sin_addr.S_un.S_un_b.s_b2 = 1;
    their_addr.sin_addr.S_un.S_un_b.s_b3 = 2;
    their_addr.sin_addr.S_un.S_un_b.s_b4 = 255;
#endif
	
	// their_addr.sin_addr.s_addr = inet_addr( "225.1.1.1" );

    memset(&(their_addr.sin_zero), 0, 8);     // zero the rest of the struct 
	
	// sPacket *tmpPacket = (sPacket *)Buffer;

    if ((numbytes=sendto(sockfd, Buffer, nBytes, 0,
         (struct sockaddr *)&their_addr, sizeof(struct sockaddr_in))) == SOCKET_ERROR)
    {
		//printf("\nServer: broadcast sendto() failed with error = %d.\n", WSAGetLastError());
		printf("\nServer: broadcast sendto() failed with error.\n" );
		ProcessSocketError();
        return(-1);
    }

    return(numbytes);
}   // end Broadcast()



//cMultiCast::cMultiCast(char *szMyAddress, int MyPort, char *szMultiCastAddress, int MultiCastPort)
SOCKET Socket_CreateLargeMultiCast(in_addr MyAddress, int MyPort, in_addr MultiCastAddress)
{
    SOCKET MySocket;
    int retval;

 // Get a datagram socket

    MySocket = socket(AF_INET, SOCK_DGRAM, 0);
	if (MySocket == -1) {
		perror( "Socket_CreateLargeMultiCast, socket() failed\n" );
		return -1;
	}

 // "A socket must bind to an address before calling setsockopt"

    struct sockaddr_in MyAddr;

    memset(&MyAddr, 0, sizeof(MyAddr));
    MyAddr.sin_family = AF_INET;
    MyAddr.sin_port = htons(MyPort);
    //MyAddr.sin_addr.s_addr = inet_addr(szMyAddress); //INADDR_ANY;
    //MyAddr.sin_addr = MyAddress; //INADDR_ANY;
	MyAddr.sin_addr.s_addr = htonl( INADDR_ANY );

	if (bind( MySocket, (struct sockaddr *)&MyAddr, sizeof(MyAddr)) == SOCKET_ERROR)
    {
		perror( "Socket_CreateLargeMultiCast, bind() failed\n" );
        ProcessSocketError();
        //closesocket(MySocket);
        return -1;
    }


 // Join the multicast group
 // Note: This is NOT necessary for the host program.

    struct ip_mreq     stMreq;

    //stMreq.imr_multiaddr.s_addr = inet_addr(szMultiCastAddress);
    //stMreq.imr_interface.s_addr = inet_addr(szMyAddress);
    //stMreq.imr_multiaddr = MultiCastAddress;
    //stMreq.imr_interface = MyAddress;

	stMreq.imr_multiaddr.s_addr=inet_addr( inet_ntoa( MultiCastAddress ) );
	stMreq.imr_interface.s_addr=htonl(INADDR_ANY);
    retval = setsockopt(MySocket, IPPROTO_IP, IP_ADD_MEMBERSHIP, (char *)&stMreq, sizeof(stMreq));
    if (retval == SOCKET_ERROR)
    {
        ProcessSocketError();
        //closesocket(MySocket);
        return -1;
    }
	

 // Set TTL to traverse multiple routers (test)
 // The default is 1 which means direct connections only.  No routers.
/*
    int iTmp;

    iTmp = 2;
    retval = setsockopt(MySocket, IPPROTO_IP, IP_MULTICAST_TTL, (char *)&iTmp, sizeof(iTmp));
    if (retval == SOCKET_ERROR)
    {
        ProcessSocketError();
    }
*/
 // Large 1MB Buffer for receiving so we don't lose data.
/*
    int optval = 0x100000;
	socklen_t optval_size = 4;

    setsockopt(MySocket, SOL_SOCKET, SO_RCVBUF, (char *)&optval, 4);
    getsockopt(MySocket, SOL_SOCKET, SO_RCVBUF, (char *)&optval, &optval_size);
    if (optval != 0x100000)
    {
        char str[256];
        sprintf(str, "ReceiveBuffer size = %d", optval);
        LogMessage(VL_Warning, str);
    }
 */

 // Disable loopback
#if 0
    iTmp = 0;
    retval = setsockopt(MySocket, IPPROTO_IP, IP_MULTICAST_LOOP, (char *)&iTmp, sizeof(iTmp));
    if (retval == SOCKET_ERROR)
    {
        ProcessSocketError();
    }
#endif

 // If you want the MultiCast to go out through more than one ethernet card...
#if 0
    unsigned long addr = inet_addr(IP_Address);
    retval = setsockopt(MySocket, IPPROTO_IP, IP_MULTICAST_IF, (char *)&addr, sizeof(addr));
#endif


// Send and Receive examples

#if 0
 // Configure an address for sendto

    memset(&m_stTo, 0, sizeof(sockaddr_in));
    m_stTo.sin_family = AF_INET;
    m_stTo.sin_addr.s_addr = inet_addr(szMultiCastAddress);
    m_stTo.sin_port = htons(MultiCastPort);
#endif


#if 0
    retval = sendto(MySocket, "multicast message", 20, 0, (struct sockaddr *)&m_stTo, sizeof(m_stTo));


 // Receiving message example

    len = sizeof(stFrom);
    ssize_t nbytes = recvfrom(MySocket, achIn, BUFSIZE, 0, (struct sockaddr *)&stFrom, &len);
	if (nbytes == -1)
		LogMessage( VL_Error, "Socket_CreateLargeMultiCast, recvfrom failed" );
	else
		LogMessage( VL_Debug, "Socket_CreateLargeMultiCast, recvfrom ok" );


 // Exit multicast group

    //stMreq.imr_multiaddr.s_addr = inet_addr("224,1,2,4");
    //stMreq.imr_interface.s_addr = netstatic[0].n_ipaddr;

    retval = setsockopt(MySocket, IPPROTO_IP, IP_DROP_MEMBERSHIP, (char *)&stMreq, sizeof(stMreq));

    retval = closesocket(MySocket);
#endif

    return MySocket;
}

//////////////////////////////////////

int ProcessSocketError()
{

#ifdef NT_COMPILE

	char s[256];
    static char szTempBuff[256];

    int iError = WSAGetLastError();

	switch (iError)
	{
		case WSAEINTR:
			strcpy(s, "WSAEINTR");
			break;

		case WSAEBADF:
			strcpy(s, "WSAEBADF");
			break;

		case WSAEACCES:
			strcpy(s, "WSAEACCES");
			break;

		case WSAEFAULT:
			strcpy(s, "WSAEFAULT");
			break;

		case WSAEINVAL:
			strcpy(s, "WSAEINVAL");
			break;

		case WSAEMFILE:
			strcpy(s, "WSAEMFILE");
			break;

		case WSAEWOULDBLOCK:
			strcpy(s, "WSAEWOULDBLOCK");
			break;

		case WSAEINPROGRESS:
			strcpy(s, "WSAEINPROGRESS");
			break;

		case WSAEALREADY:
			strcpy(s, "WSAEALREADY");
			break;

		case WSAENOTSOCK:
			strcpy(s, "WSAENOTSOCK");
			break;

		case WSAEDESTADDRREQ:
			strcpy(s, "WSAEDESTADDRREQ");
			break;

		case WSAEMSGSIZE:
			strcpy(s, "WSAEMSGSIZE");
			break;

		case WSAEPROTOTYPE:
			strcpy(s, "WSAEPROTOTYPE");
			break;

		case WSAENOPROTOOPT:
			strcpy(s, "WSAENOPROTOOPT");
			break;

		case WSAEPROTONOSUPPORT:
			strcpy(s, "WSAEPROTONOSUPPORT");
			break;

		case WSAESOCKTNOSUPPORT:
			strcpy(s, "WSAESOCKTNOSUPPORT");
			break;

		case WSAEOPNOTSUPP:
			strcpy(s, "WSAEOPNOTSUPP");
			break;

		case WSAEPFNOSUPPORT:
			strcpy(s, "WSAEPFNOSUPPORT");
			break;

		case WSAEAFNOSUPPORT:
			strcpy(s, "WSAEAFNOSUPPORT");
			break;

		case WSAEADDRINUSE:
			strcpy(s, "WSAEADDRINUSE");
			break;

		case WSAEADDRNOTAVAIL:
			strcpy(s, "WSAEADDRNOTAVAIL");
			break;

		case WSAENETDOWN:
			strcpy(s, "WSAENETDOWN");
			break;

		case WSAENETUNREACH:
			strcpy(s, "WSAENETUNREACH");
			break;

		case WSAENETRESET:
			strcpy(s, "WSAENETRESET");
			break;

		case WSAECONNABORTED:
			strcpy(s, "WSAECONNABORTED");
			break;

		case WSAECONNRESET:
			strcpy(s, "WSAECONNRESET");
			break;

		case WSAENOBUFS:
			strcpy(s, "WSAENOBUFS");
			break;

		case WSAEISCONN:
			strcpy(s, "WSAEISCONN");
			break;

		case WSAENOTCONN:
			strcpy(s, "WSAENOTCONN");
			break;

		case WSAESHUTDOWN:
			strcpy(s, "WSAESHUTDOWN");
			break;

		case WSAETOOMANYREFS:
			strcpy(s, "WSAETOOMANYREFS");
			break;

		case WSAETIMEDOUT:
			strcpy(s, "WSAETIMEDOUT");
			break;

		case WSAECONNREFUSED:
			strcpy(s, "WSAECONNREFUSED");
			break;

		case WSAELOOP:
			strcpy(s, "WSAELOOP");
			break;

		case WSAENAMETOOLONG:
			strcpy(s, "WSAENAMETOOLONG");
			break;

		case WSAEHOSTDOWN:
			strcpy(s, "WSAEHOSTDOWN");
			break;

		case WSAEHOSTUNREACH:
			strcpy(s, "WSAEHOSTUNREACH");
			break;

		case WSAENOTEMPTY:
			strcpy(s, "WSAENOTEMPTY");
			break;

		case WSAEPROCLIM:
			strcpy(s, "WSAEPROCLIM");
			break;

		case WSAEUSERS:
			strcpy(s, "WSAEUSERS");
			break;

		case WSAEDQUOT:
			strcpy(s, "WSAEDQUOT");
			break;

		case WSAESTALE:
			strcpy(s, "WSAESTALE");
			break;

		case WSAEREMOTE:
			strcpy(s, "WSAEREMOTE");
			break;

		case WSASYSNOTREADY:
			strcpy(s, "WSASYSNOTREADY");
			break;

		case WSAVERNOTSUPPORTED:
			strcpy(s, "WSAVERNOTSUPPORTED");
			break;

		case WSANOTINITIALISED:
			strcpy(s, "WSANOTINITIALISED");
			break;

		case WSAEDISCON:
			strcpy(s, "WSAEDISCON");
			break;

		case WSAENOMORE:
			strcpy(s, "WSAENOMORE");
			break;

		case WSAECANCELLED:
			strcpy(s, "WSAECANCELLED");
			break;

		case WSAEINVALIDPROCTABLE:
			strcpy(s, "WSAEINVALIDPROCTABLE");
			break;

		case WSAEINVALIDPROVIDER:
			strcpy(s, "WSAEINVALIDPROVIDER");
			break;

		case WSAEPROVIDERFAILEDINIT:
			strcpy(s, "WSAEPROVIDERFAILEDINIT");
			break;

		case WSASYSCALLFAILURE:
			strcpy(s, "WSASYSCALLFAILURE");
			break;

		case WSASERVICE_NOT_FOUND:
			strcpy(s, "WSASERVICE_NOT_FOUND");
			break;

		case WSATYPE_NOT_FOUND:
			strcpy(s, "WSATYPE_NOT_FOUND");
			break;

		case WSA_E_NO_MORE:
			strcpy(s, "WSA_E_NO_MORE");
			break;

		case WSA_E_CANCELLED:
			strcpy(s, "WSA_E_CANCELLED");
			break;

		case WSAEREFUSED:
			strcpy(s, "WSAEREFUSED");
			break;

		default:
			strcpy(s, "Unknown socket error");
			break;
	}

	sprintf(szTempBuff, "Socket error %d: %s", 
			iError, s);

    LogMessage(VL_Error, szTempBuff);

    return iError;

#else

    LogMessage( VL_Error, "Socket error ?" );
    return( 1 );

#endif
}


int EVaRT2_GetAllOfMyAddresses(unsigned long Addresses[], int nMax)
{
    struct hostent *haddr;
    char           szMyName[128];
    unsigned long  NameLength = 128;
    int            nAddresses;
	
    if (gethostname( szMyName, NameLength ) == -1) {
        return -1;
    }
	printf("Name of client computer: %s\n", szMyName); // (client?)

    if (!(haddr=gethostbyname(szMyName)))
	{
		printf("Error, gethostbyname returned NULL.. Error No: %d\n", h_errno);
        return -1;
    }

    for (nAddresses=0 ; nAddresses<nMax ; nAddresses++)
    {
        if (haddr->h_addr_list[nAddresses] == NULL)
        {
            break;
        }

        memcpy(&Addresses[nAddresses], haddr->h_addr_list[nAddresses], 4);
    }

    return nAddresses;

}
